-- DataMigrationBackup4 SQL Dump
-- Generated at: 2026-03-14 17:38:18

-- Table: dtb_authority_role
INSERT INTO dtb_authority_role (id, authority_id, creator_id, deny_url, create_date, update_date, discriminator_type) VALUES (1, 1, NULL, '/api', '2026-03-14 08:33:47', '2026-03-14 08:33:47', 'authorityrole');

-- Table: dtb_base_info
INSERT INTO dtb_base_info (id, country_id, pref_id, company_name, company_kana, postal_code, addr01, addr02, phone_number, business_hour, email01, email02, email03, email04, shop_name, shop_kana, shop_name_eng, update_date, good_traded, message, delivery_free_amount, delivery_free_quantity, option_mypage_order_status_display, option_nostock_hidden, option_favorite_product, option_product_delivery_fee, invoice_registration_number, option_product_tax_rule, option_customer_activate, option_remember_me, option_mail_notifier, authentication_key, php_path, option_point, basic_point_rate, point_conversion_rate, discriminator_type, site_kit_site_id, site_kit_site_secret) VALUES (1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'admin@example.com', 'admin@example.com', 'admin@example.com', 'admin@example.com', 'EC-CUBE SHOP', NULL, NULL, '2026-03-14 08:29:55', NULL, NULL, NULL, NULL, 1, 0, 1, 0, NULL, 0, 1, 1, 1, '3r8h0sPnCMXOGEetxKV721Z4nQNiRPhFRQ7e8Kuh', NULL, 1, 1, 1, 'baseinfo', NULL, NULL);

-- Table: dtb_block
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (1, 10, 'カート', 'cart', 0, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'block');
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (2, 10, 'カテゴリ', 'category', 0, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'block');
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (3, 10, 'カテゴリナビ(PC)', 'category_nav_pc', 0, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'block');
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (4, 10, 'カテゴリナビ(SP)', 'category_nav_sp', 0, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'block');
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (5, 10, '新入荷商品特集', 'eyecatch', 0, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'block');
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (6, 10, 'フッター', 'footer', 0, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'block');
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (7, 10, 'ヘッダー(商品検索・ログインナビ・カート)', 'header', 0, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'block');
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (8, 10, 'ログインナビ(共通)', 'login', 0, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'block');
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (9, 10, 'ログインナビ(SP)', 'login_sp', 0, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'block');
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (10, 10, 'ロゴ', 'logo', 0, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'block');
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (11, 10, '新着商品', 'new_item', 0, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'block');
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (12, 10, '新着情報', 'news', 0, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'block');
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (13, 10, '商品検索', 'search_product', 1, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'block');
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (14, 10, 'トピック', 'topic', 0, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'block');
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (17, 10, 'カレンダー', 'calendar', 1, 0, '2021-03-16 12:00:00', '2021-03-16 12:00:00', 'block');
INSERT INTO dtb_block (id, device_type_id, block_name, file_name, use_controller, deletable, create_date, update_date, discriminator_type) VALUES (18, 10, 'おすすめ商品', 'recommend_product_block', 0, 0, '2026-03-14 08:35:18', '2026-03-14 08:35:18', 'block');

-- Table: dtb_block_position
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (3, 7, 1, 1, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (3, 10, 1, 2, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (3, 3, 1, 3, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (7, 5, 1, 1, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (7, 14, 1, 2, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (7, 11, 1, 3, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (7, 2, 1, 4, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (7, 12, 1, 5, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (10, 6, 1, 1, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (11, 13, 1, 1, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (11, 4, 1, 2, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (11, 9, 1, 3, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (3, 7, 2, 1, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (3, 10, 2, 2, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (3, 3, 2, 3, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (10, 6, 2, 1, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (11, 13, 2, 1, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (11, 4, 2, 2, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (11, 9, 2, 3, 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES (7, 18, 2, 1, 'blockposition');

-- Table: dtb_calendar

-- Table: dtb_cart

-- Table: dtb_cart_item

-- Table: dtb_category
INSERT INTO dtb_category (id, parent_category_id, creator_id, category_name, hierarchy, sort_no, create_date, update_date, discriminator_type) VALUES (1, NULL, NULL, 'ジェラート', 1, 5, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'category');
INSERT INTO dtb_category (id, parent_category_id, creator_id, category_name, hierarchy, sort_no, create_date, update_date, discriminator_type) VALUES (2, NULL, NULL, '新入荷', 1, 6, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'category');
INSERT INTO dtb_category (id, parent_category_id, creator_id, category_name, hierarchy, sort_no, create_date, update_date, discriminator_type) VALUES (3, 1, NULL, '彩のデザート', 2, 3, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'category');
INSERT INTO dtb_category (id, parent_category_id, creator_id, category_name, hierarchy, sort_no, create_date, update_date, discriminator_type) VALUES (4, 3, NULL, 'CUBE', 3, 2, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'category');
INSERT INTO dtb_category (id, parent_category_id, creator_id, category_name, hierarchy, sort_no, create_date, update_date, discriminator_type) VALUES (5, NULL, NULL, 'アイスサンド', 1, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'category');
INSERT INTO dtb_category (id, parent_category_id, creator_id, category_name, hierarchy, sort_no, create_date, update_date, discriminator_type) VALUES (6, 5, NULL, 'フルーツ', 2, 4, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'category');

-- Table: dtb_class_category
INSERT INTO dtb_class_category (id, class_name_id, creator_id, backend_name, name, sort_no, visible, create_date, update_date, discriminator_type) VALUES (1, 1, NULL, 'チョコ', 'チョコ', 3, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'classcategory');
INSERT INTO dtb_class_category (id, class_name_id, creator_id, backend_name, name, sort_no, visible, create_date, update_date, discriminator_type) VALUES (2, 1, NULL, '抹茶', '抹茶', 2, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'classcategory');
INSERT INTO dtb_class_category (id, class_name_id, creator_id, backend_name, name, sort_no, visible, create_date, update_date, discriminator_type) VALUES (3, 1, NULL, 'バニラ', 'バニラ', 1, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'classcategory');
INSERT INTO dtb_class_category (id, class_name_id, creator_id, backend_name, name, sort_no, visible, create_date, update_date, discriminator_type) VALUES (4, 2, NULL, '16mm × 16mm', '16mm × 16mm', 3, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'classcategory');
INSERT INTO dtb_class_category (id, class_name_id, creator_id, backend_name, name, sort_no, visible, create_date, update_date, discriminator_type) VALUES (5, 2, NULL, '32mm × 32mm', '32mm × 32mm', 2, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'classcategory');
INSERT INTO dtb_class_category (id, class_name_id, creator_id, backend_name, name, sort_no, visible, create_date, update_date, discriminator_type) VALUES (6, 2, NULL, '64cm × 64cm', '64cm × 64cm', 1, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'classcategory');

-- Table: dtb_class_name
INSERT INTO dtb_class_name (id, creator_id, backend_name, name, sort_no, create_date, update_date, discriminator_type) VALUES (1, NULL, 'CUBE用味', 'フレーバー', 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'classname');
INSERT INTO dtb_class_name (id, creator_id, backend_name, name, sort_no, create_date, update_date, discriminator_type) VALUES (2, NULL, 'CUBE用サイズ', 'サイズ', 2, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'classname');

-- Table: dtb_csv
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (1, 1, NULL, 'Eccube\\Entity\\Product', 'id', NULL, '商品ID', 1, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (2, 1, NULL, 'Eccube\\Entity\\Product', 'Status', 'id', '公開ステータス(ID)', 2, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (3, 1, NULL, 'Eccube\\Entity\\Product', 'Status', 'name', '公開ステータス(名称)', 3, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (4, 1, NULL, 'Eccube\\Entity\\Product', 'name', NULL, '商品名', 4, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (5, 1, NULL, 'Eccube\\Entity\\Product', 'note', NULL, 'ショップ用メモ欄', 5, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (6, 1, NULL, 'Eccube\\Entity\\Product', 'description_list', NULL, '商品説明(一覧)', 6, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (7, 1, NULL, 'Eccube\\Entity\\Product', 'description_detail', NULL, '商品説明(詳細)', 7, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (8, 1, NULL, 'Eccube\\Entity\\Product', 'search_word', NULL, '検索ワード', 8, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (9, 1, NULL, 'Eccube\\Entity\\Product', 'free_area', NULL, 'フリーエリア', 9, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (10, 1, NULL, 'Eccube\\Entity\\ProductClass', 'id', NULL, '商品規格ID', 10, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (11, 1, NULL, 'Eccube\\Entity\\ProductClass', 'SaleType', 'id', '販売種別(ID)', 11, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (12, 1, NULL, 'Eccube\\Entity\\ProductClass', 'SaleType', 'name', '販売種別(名称)', 12, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (13, 1, NULL, 'Eccube\\Entity\\ProductClass', 'ClassCategory1', 'id', '規格分類1(ID)', 13, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (14, 1, NULL, 'Eccube\\Entity\\ProductClass', 'ClassCategory1', 'name', '規格分類1(名称)', 14, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (15, 1, NULL, 'Eccube\\Entity\\ProductClass', 'ClassCategory2', 'id', '規格分類2(ID)', 15, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (16, 1, NULL, 'Eccube\\Entity\\ProductClass', 'ClassCategory2', 'name', '規格分類2(名称)', 16, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (17, 1, NULL, 'Eccube\\Entity\\ProductClass', 'DeliveryDuration', 'id', '発送日目安(ID)', 17, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (18, 1, NULL, 'Eccube\\Entity\\ProductClass', 'DeliveryDuration', 'name', '発送日目安(名称)', 18, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (19, 1, NULL, 'Eccube\\Entity\\ProductClass', 'code', NULL, '商品コード', 19, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (20, 1, NULL, 'Eccube\\Entity\\ProductClass', 'stock', NULL, '在庫数', 20, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (21, 1, NULL, 'Eccube\\Entity\\ProductClass', 'stock_unlimited', NULL, '在庫数無制限フラグ', 21, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (22, 1, NULL, 'Eccube\\Entity\\ProductClass', 'sale_limit', NULL, '販売制限数', 22, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (23, 1, NULL, 'Eccube\\Entity\\ProductClass', 'price01', NULL, '通常価格', 23, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (24, 1, NULL, 'Eccube\\Entity\\ProductClass', 'price02', NULL, '販売価格', 24, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (25, 1, NULL, 'Eccube\\Entity\\ProductClass', 'delivery_fee', NULL, '送料', 25, 0, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (26, 1, NULL, 'Eccube\\Entity\\Product', 'ProductImage', 'file_name', '商品画像', 26, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (27, 1, NULL, 'Eccube\\Entity\\Product', 'ProductCategories', 'category_id', '商品カテゴリ(ID)', 27, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (28, 1, NULL, 'Eccube\\Entity\\Product', 'ProductCategories', 'Category', '商品カテゴリ(名称)', 28, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (29, 1, NULL, 'Eccube\\Entity\\Product', 'ProductTag', 'tag_id', 'タグ(ID)', 29, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (30, 1, NULL, 'Eccube\\Entity\\Product', 'ProductTag', 'Tag', 'タグ(名称)', 30, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (31, 2, NULL, 'Eccube\\Entity\\Customer', 'id', NULL, '会員ID', 1, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (32, 2, NULL, 'Eccube\\Entity\\Customer', 'name01', NULL, 'お名前(姓)', 2, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (33, 2, NULL, 'Eccube\\Entity\\Customer', 'name02', NULL, 'お名前(名)', 3, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (34, 2, NULL, 'Eccube\\Entity\\Customer', 'kana01', NULL, 'お名前(セイ)', 4, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (35, 2, NULL, 'Eccube\\Entity\\Customer', 'kana02', NULL, 'お名前(メイ)', 5, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (36, 2, NULL, 'Eccube\\Entity\\Customer', 'company_name', NULL, '会社名', 6, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (37, 2, NULL, 'Eccube\\Entity\\Customer', 'postal_code', NULL, '郵便番号', 7, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (38, 2, NULL, 'Eccube\\Entity\\Customer', 'Pref', 'id', '都道府県(ID)', 9, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (39, 2, NULL, 'Eccube\\Entity\\Customer', 'Pref', 'name', '都道府県(名称)', 10, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (40, 2, NULL, 'Eccube\\Entity\\Customer', 'addr01', NULL, '住所1', 11, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (41, 2, NULL, 'Eccube\\Entity\\Customer', 'addr02', NULL, '住所2', 12, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (42, 2, NULL, 'Eccube\\Entity\\Customer', 'email', NULL, 'メールアドレス', 13, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (43, 2, NULL, 'Eccube\\Entity\\Customer', 'phone_number', NULL, 'TEL', 14, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (44, 2, NULL, 'Eccube\\Entity\\Customer', 'Sex', 'id', '性別(ID)', 20, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (45, 2, NULL, 'Eccube\\Entity\\Customer', 'Sex', 'name', '性別(名称)', 21, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (46, 2, NULL, 'Eccube\\Entity\\Customer', 'Job', 'id', '職業(ID)', 22, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (47, 2, NULL, 'Eccube\\Entity\\Customer', 'Job', 'name', '職業(名称)', 23, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (48, 2, NULL, 'Eccube\\Entity\\Customer', 'birth', NULL, '誕生日', 24, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (49, 2, NULL, 'Eccube\\Entity\\Customer', 'first_buy_date', NULL, '初回購入日', 25, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (50, 2, NULL, 'Eccube\\Entity\\Customer', 'last_buy_date', NULL, '最終購入日', 26, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (51, 2, NULL, 'Eccube\\Entity\\Customer', 'buy_times', NULL, '購入回数', 27, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (52, 2, NULL, 'Eccube\\Entity\\Customer', 'note', NULL, 'ショップ用メモ欄', 28, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (53, 2, NULL, 'Eccube\\Entity\\Customer', 'Status', 'id', '会員ステータス(ID)', 29, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (54, 2, NULL, 'Eccube\\Entity\\Customer', 'Status', 'name', '会員ステータス(名称)', 30, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (55, 2, NULL, 'Eccube\\Entity\\Customer', 'create_date', NULL, '登録日', 31, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (56, 2, NULL, 'Eccube\\Entity\\Customer', 'update_date', NULL, '更新日', 32, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (57, 3, NULL, 'Eccube\\Entity\\Order', 'id', NULL, '注文ID', 1, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (58, 3, NULL, 'Eccube\\Entity\\Order', 'order_no', NULL, '注文番号', 2, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (59, 3, NULL, 'Eccube\\Entity\\Order', 'Customer', 'id', '会員ID', 3, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (60, 3, NULL, 'Eccube\\Entity\\Order', 'name01', NULL, 'お名前(姓)', 4, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (61, 3, NULL, 'Eccube\\Entity\\Order', 'name02', NULL, 'お名前(名)', 5, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (62, 3, NULL, 'Eccube\\Entity\\Order', 'kana01', NULL, 'お名前(セイ)', 6, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (63, 3, NULL, 'Eccube\\Entity\\Order', 'kana02', NULL, 'お名前(メイ)', 7, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (64, 3, NULL, 'Eccube\\Entity\\Order', 'company_name', NULL, '会社名', 8, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (65, 3, NULL, 'Eccube\\Entity\\Order', 'postal_code', NULL, '郵便番号', 9, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (66, 3, NULL, 'Eccube\\Entity\\Order', 'Pref', 'id', '都道府県(ID)', 10, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (67, 3, NULL, 'Eccube\\Entity\\Order', 'Pref', 'name', '都道府県(名称)', 11, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (68, 3, NULL, 'Eccube\\Entity\\Order', 'addr01', NULL, '住所1', 12, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (69, 3, NULL, 'Eccube\\Entity\\Order', 'addr02', NULL, '住所2', 13, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (70, 3, NULL, 'Eccube\\Entity\\Order', 'email', NULL, 'メールアドレス', 14, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (71, 3, NULL, 'Eccube\\Entity\\Order', 'phone_number', NULL, 'TEL', 15, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (72, 3, NULL, 'Eccube\\Entity\\Order', 'Sex', 'id', '性別(ID)', 16, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (73, 3, NULL, 'Eccube\\Entity\\Order', 'Sex', 'name', '性別(名称)', 17, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (74, 3, NULL, 'Eccube\\Entity\\Order', 'Job', 'id', '職業(ID)', 18, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (75, 3, NULL, 'Eccube\\Entity\\Order', 'Job', 'name', '職業(名称)', 19, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (76, 3, NULL, 'Eccube\\Entity\\Order', 'birth', NULL, '誕生日', 20, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (77, 3, NULL, 'Eccube\\Entity\\Order', 'note', NULL, 'ショップ用メモ欄', 21, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (78, 3, NULL, 'Eccube\\Entity\\Order', 'subtotal', NULL, '小計', 22, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (79, 3, NULL, 'Eccube\\Entity\\Order', 'discount', NULL, '値引き', 23, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (80, 3, NULL, 'Eccube\\Entity\\Order', 'delivery_fee_total', NULL, '送料', 24, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (81, 3, NULL, 'Eccube\\Entity\\Order', 'tax', NULL, '税金', 25, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (82, 3, NULL, 'Eccube\\Entity\\Order', 'total', NULL, '合計', 26, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (83, 3, NULL, 'Eccube\\Entity\\Order', 'payment_total', NULL, '支払合計', 27, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (84, 3, NULL, 'Eccube\\Entity\\Order', 'OrderStatus', 'id', '対応状況(ID)', 28, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (85, 3, NULL, 'Eccube\\Entity\\Order', 'OrderStatus', 'name', '対応状況(名称)', 29, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (86, 3, NULL, 'Eccube\\Entity\\Order', 'Payment', 'id', '支払方法(ID)', 30, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (87, 3, NULL, 'Eccube\\Entity\\Order', 'payment_method', NULL, '支払方法(名称)', 31, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (88, 3, NULL, 'Eccube\\Entity\\Order', 'order_date', NULL, '受注日', 32, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (89, 3, NULL, 'Eccube\\Entity\\Order', 'payment_date', NULL, '入金日', 33, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (90, 3, NULL, 'Eccube\\Entity\\OrderItem', 'id', NULL, '注文詳細ID', 34, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (91, 3, NULL, 'Eccube\\Entity\\OrderItem', 'Product', 'id', '商品ID', 35, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (92, 3, NULL, 'Eccube\\Entity\\OrderItem', 'ProductClass', 'id', '商品規格ID', 36, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (93, 3, NULL, 'Eccube\\Entity\\OrderItem', 'product_name', NULL, '商品名', 37, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (94, 3, NULL, 'Eccube\\Entity\\OrderItem', 'product_code', NULL, '商品コード', 38, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (95, 3, NULL, 'Eccube\\Entity\\OrderItem', 'class_name1', NULL, '規格名1', 39, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (96, 3, NULL, 'Eccube\\Entity\\OrderItem', 'class_name2', NULL, '規格名2', 40, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (97, 3, NULL, 'Eccube\\Entity\\OrderItem', 'class_category_name1', NULL, '規格分類名1', 41, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (98, 3, NULL, 'Eccube\\Entity\\OrderItem', 'class_category_name2', NULL, '規格分類名2', 42, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (99, 3, NULL, 'Eccube\\Entity\\OrderItem', 'price', NULL, '価格', 43, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (100, 3, NULL, 'Eccube\\Entity\\OrderItem', 'quantity', NULL, '個数', 44, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (101, 3, NULL, 'Eccube\\Entity\\OrderItem', 'tax_rate', NULL, '税率', 45, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (102, 3, NULL, 'Eccube\\Entity\\OrderItem', 'tax_rule', NULL, '税率ルール(ID)', 46, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (103, 3, NULL, 'Eccube\\Entity\\OrderItem', 'OrderItemType', 'id', '明細区分(ID)', 47, 1, '2018-07-23 09:00:00', '2018-07-23 09:00:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (104, 3, NULL, 'Eccube\\Entity\\OrderItem', 'OrderItemType', 'name', '明細区分(名称)', 48, 1, '2018-07-23 09:00:00', '2018-07-23 09:00:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (105, 3, NULL, 'Eccube\\Entity\\Shipping', 'id', NULL, '出荷ID', 49, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (106, 3, NULL, 'Eccube\\Entity\\Shipping', 'name01', NULL, '配送先_お名前(姓)', 50, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (107, 3, NULL, 'Eccube\\Entity\\Shipping', 'name02', NULL, '配送先_お名前(名)', 51, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (108, 3, NULL, 'Eccube\\Entity\\Shipping', 'kana01', NULL, '配送先_お名前(セイ)', 52, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (109, 3, NULL, 'Eccube\\Entity\\Shipping', 'kana02', NULL, '配送先_お名前(メイ)', 53, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (110, 3, NULL, 'Eccube\\Entity\\Shipping', 'company_name', NULL, '配送先_会社名', 54, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (111, 3, NULL, 'Eccube\\Entity\\Shipping', 'postal_code', NULL, '配送先_郵便番号', 55, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (112, 3, NULL, 'Eccube\\Entity\\Shipping', 'Pref', 'id', '配送先_都道府県(ID)', 56, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (113, 3, NULL, 'Eccube\\Entity\\Shipping', 'Pref', 'name', '配送先_都道府県(名称)', 57, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (114, 3, NULL, 'Eccube\\Entity\\Shipping', 'addr01', NULL, '配送先_住所1', 58, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (115, 3, NULL, 'Eccube\\Entity\\Shipping', 'addr02', NULL, '配送先_住所2', 59, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (116, 3, NULL, 'Eccube\\Entity\\Shipping', 'phone_number', NULL, '配送先_TEL', 60, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (117, 3, NULL, 'Eccube\\Entity\\Shipping', 'Delivery', 'id', '配送業者(ID)', 61, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (118, 3, NULL, 'Eccube\\Entity\\Shipping', 'shipping_delivery_name', NULL, '配送業者(名称)', 62, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (119, 3, NULL, 'Eccube\\Entity\\Shipping', 'time_id', NULL, 'お届け時間ID', 63, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (120, 3, NULL, 'Eccube\\Entity\\Shipping', 'shipping_delivery_time', NULL, 'お届け時間(名称)', 64, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (121, 3, NULL, 'Eccube\\Entity\\Shipping', 'shipping_delivery_date', NULL, 'お届け希望日', 65, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (123, 3, NULL, 'Eccube\\Entity\\Shipping', 'shipping_delivery_fee', NULL, '送料', 67, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (124, 3, NULL, 'Eccube\\Entity\\Shipping', 'shipping_date', NULL, '発送日', 68, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (125, 3, NULL, 'Eccube\\Entity\\Shipping', 'tracking_number', NULL, '出荷伝票番号', 69, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (126, 3, NULL, 'Eccube\\Entity\\Shipping', 'note', NULL, '配達用メモ', 70, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (127, 3, NULL, 'Eccube\\Entity\\Shipping', 'mail_send_date', NULL, '出荷メール送信日', 71, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (128, 4, NULL, 'Eccube\\Entity\\Order', 'id', NULL, '注文ID', 1, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (129, 4, NULL, 'Eccube\\Entity\\Order', 'order_no', NULL, '注文番号', 2, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (130, 4, NULL, 'Eccube\\Entity\\Order', 'Customer', 'id', '会員ID', 3, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (131, 4, NULL, 'Eccube\\Entity\\Order', 'name01', NULL, 'お名前(姓)', 4, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (132, 4, NULL, 'Eccube\\Entity\\Order', 'name02', NULL, 'お名前(名)', 5, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (133, 4, NULL, 'Eccube\\Entity\\Order', 'kana01', NULL, 'お名前(セイ)', 6, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (134, 4, NULL, 'Eccube\\Entity\\Order', 'kana02', NULL, 'お名前(メイ)', 7, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (135, 4, NULL, 'Eccube\\Entity\\Order', 'company_name', NULL, '会社名', 8, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (136, 4, NULL, 'Eccube\\Entity\\Order', 'postal_code', NULL, '郵便番号', 9, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (137, 4, NULL, 'Eccube\\Entity\\Order', 'Pref', 'id', '都道府県(ID)', 10, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (138, 4, NULL, 'Eccube\\Entity\\Order', 'Pref', 'name', '都道府県(名称)', 11, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (139, 4, NULL, 'Eccube\\Entity\\Order', 'addr01', NULL, '住所1', 12, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (140, 4, NULL, 'Eccube\\Entity\\Order', 'addr02', NULL, '住所2', 13, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (141, 4, NULL, 'Eccube\\Entity\\Order', 'email', NULL, 'メールアドレス', 14, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (142, 4, NULL, 'Eccube\\Entity\\Order', 'phone_number', NULL, 'TEL', 15, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (143, 4, NULL, 'Eccube\\Entity\\Order', 'Sex', 'id', '性別(ID)', 16, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (144, 4, NULL, 'Eccube\\Entity\\Order', 'Sex', 'name', '性別(名称)', 17, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (145, 4, NULL, 'Eccube\\Entity\\Order', 'Job', 'id', '職業(ID)', 18, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (146, 4, NULL, 'Eccube\\Entity\\Order', 'Job', 'name', '職業(名称)', 19, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (147, 4, NULL, 'Eccube\\Entity\\Order', 'birth', NULL, '誕生日', 20, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (148, 4, NULL, 'Eccube\\Entity\\Order', 'note', NULL, 'ショップ用メモ欄', 21, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (149, 4, NULL, 'Eccube\\Entity\\Order', 'subtotal', NULL, '小計', 22, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (150, 4, NULL, 'Eccube\\Entity\\Order', 'discount', NULL, '値引き', 23, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (151, 4, NULL, 'Eccube\\Entity\\Order', 'delivery_fee_total', NULL, '送料', 24, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (152, 4, NULL, 'Eccube\\Entity\\Order', 'tax', NULL, '税金', 25, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (153, 4, NULL, 'Eccube\\Entity\\Order', 'total', NULL, '合計', 26, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (154, 4, NULL, 'Eccube\\Entity\\Order', 'payment_total', NULL, '支払合計', 27, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (155, 4, NULL, 'Eccube\\Entity\\Order', 'OrderStatus', 'id', '対応状況(ID)', 28, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (156, 4, NULL, 'Eccube\\Entity\\Order', 'OrderStatus', 'name', '対応状況(名称)', 29, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (157, 4, NULL, 'Eccube\\Entity\\Order', 'Payment', 'id', '支払方法(ID)', 30, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (158, 4, NULL, 'Eccube\\Entity\\Order', 'payment_method', NULL, '支払方法(名称)', 31, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (159, 4, NULL, 'Eccube\\Entity\\Order', 'order_date', NULL, '受注日', 32, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (160, 4, NULL, 'Eccube\\Entity\\Order', 'payment_date', NULL, '入金日', 33, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (161, 4, NULL, 'Eccube\\Entity\\OrderItem', 'id', NULL, '注文詳細ID', 34, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (162, 4, NULL, 'Eccube\\Entity\\OrderItem', 'Product', 'id', '商品ID', 35, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (163, 4, NULL, 'Eccube\\Entity\\OrderItem', 'ProductClass', 'id', '商品規格ID', 36, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (164, 4, NULL, 'Eccube\\Entity\\OrderItem', 'product_name', NULL, '商品名', 37, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (165, 4, NULL, 'Eccube\\Entity\\OrderItem', 'product_code', NULL, '商品コード', 38, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (166, 4, NULL, 'Eccube\\Entity\\OrderItem', 'class_name1', NULL, '規格名1', 39, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (167, 4, NULL, 'Eccube\\Entity\\OrderItem', 'class_name2', NULL, '規格名2', 40, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (168, 4, NULL, 'Eccube\\Entity\\OrderItem', 'class_category_name1', NULL, '規格分類名1', 41, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (169, 4, NULL, 'Eccube\\Entity\\OrderItem', 'class_category_name2', NULL, '規格分類名2', 42, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (170, 4, NULL, 'Eccube\\Entity\\OrderItem', 'price', NULL, '価格', 43, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (171, 4, NULL, 'Eccube\\Entity\\OrderItem', 'quantity', NULL, '個数', 44, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (172, 4, NULL, 'Eccube\\Entity\\OrderItem', 'tax_rate', NULL, '税率', 45, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (173, 4, NULL, 'Eccube\\Entity\\OrderItem', 'tax_rule', NULL, '税率ルール(ID)', 46, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (174, 4, NULL, 'Eccube\\Entity\\OrderItem', 'OrderItemType', 'id', '明細区分(ID)', 47, 1, '2018-07-23 09:00:00', '2018-07-23 09:00:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (175, 4, NULL, 'Eccube\\Entity\\OrderItem', 'OrderItemType', 'name', '明細区分(名称)', 48, 1, '2018-07-23 09:00:00', '2018-07-23 09:00:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (176, 4, NULL, 'Eccube\\Entity\\Shipping', 'id', NULL, '出荷ID', 49, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (177, 4, NULL, 'Eccube\\Entity\\Shipping', 'name01', NULL, '配送先_お名前(姓)', 50, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (178, 4, NULL, 'Eccube\\Entity\\Shipping', 'name02', NULL, '配送先_お名前(名)', 51, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (179, 4, NULL, 'Eccube\\Entity\\Shipping', 'kana01', NULL, '配送先_お名前(セイ)', 52, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (180, 4, NULL, 'Eccube\\Entity\\Shipping', 'kana02', NULL, '配送先_お名前(メイ)', 53, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (181, 4, NULL, 'Eccube\\Entity\\Shipping', 'company_name', NULL, '配送先_会社名', 54, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (182, 4, NULL, 'Eccube\\Entity\\Shipping', 'postal_code', NULL, '配送先_郵便番号', 55, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (183, 4, NULL, 'Eccube\\Entity\\Shipping', 'Pref', 'id', '配送先_都道府県(ID)', 56, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (184, 4, NULL, 'Eccube\\Entity\\Shipping', 'Pref', 'name', '配送先_都道府県(名称)', 57, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (185, 4, NULL, 'Eccube\\Entity\\Shipping', 'addr01', NULL, '配送先_住所1', 58, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (186, 4, NULL, 'Eccube\\Entity\\Shipping', 'addr02', NULL, '配送先_住所2', 59, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (187, 4, NULL, 'Eccube\\Entity\\Shipping', 'phone_number', NULL, '配送先_TEL', 60, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (188, 4, NULL, 'Eccube\\Entity\\Shipping', 'Delivery', 'id', '配送業者(ID)', 61, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (189, 4, NULL, 'Eccube\\Entity\\Shipping', 'shipping_delivery_name', NULL, '配送業者(名称)', 62, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (190, 4, NULL, 'Eccube\\Entity\\Shipping', 'time_id', NULL, 'お届け時間ID', 63, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (191, 4, NULL, 'Eccube\\Entity\\Shipping', 'shipping_delivery_time', NULL, 'お届け時間(名称)', 64, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (192, 4, NULL, 'Eccube\\Entity\\Shipping', 'shipping_delivery_date', NULL, 'お届け希望日', 65, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (194, 4, NULL, 'Eccube\\Entity\\Shipping', 'shipping_delivery_fee', NULL, '送料', 67, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (195, 4, NULL, 'Eccube\\Entity\\Shipping', 'shipping_date', NULL, '発送日', 68, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (196, 4, NULL, 'Eccube\\Entity\\Shipping', 'tracking_number', NULL, '出荷伝票番号', 69, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (197, 4, NULL, 'Eccube\\Entity\\Shipping', 'note', NULL, '配達用メモ', 70, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (198, 4, NULL, 'Eccube\\Entity\\Shipping', 'mail_send_date', NULL, '出荷メール送信日', 71, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (199, 5, NULL, 'Eccube\\Entity\\Category', 'id', NULL, 'カテゴリID', 1, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (200, 5, NULL, 'Eccube\\Entity\\Category', 'sort_no', NULL, '表示ランク', 2, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (201, 5, NULL, 'Eccube\\Entity\\Category', 'name', NULL, 'カテゴリ名', 3, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (202, 5, NULL, 'Eccube\\Entity\\Category', 'Parent', 'id', '親カテゴリID', 4, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (203, 5, NULL, 'Eccube\\Entity\\Category', 'level', NULL, '階層', 5, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (204, 1, NULL, 'Eccube\\Entity\\ProductClass', 'TaxRule', 'tax_rate', '税率', 31, 0, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (205, 2, NULL, 'Eccube\\Entity\\Customer', 'point', NULL, 'ポイント', 33, 1, '2017-03-07 10:14:00', '2017-03-07 10:14:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (206, 1, NULL, 'Eccube\\Entity\\ProductClass', 'visible', NULL, '商品規格表示フラグ', 32, 0, '2022-11-24 00:00:00', '2022-11-24 00:00:00', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (207, 6, NULL, 'Plugin\ProductReview42\Entity\ProductReview', 'Product', 'name', '商品名', 1, 1, '2026-03-14 08:34:57', '2026-03-14 08:34:57', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (208, 6, NULL, 'Plugin\ProductReview42\Entity\ProductReview', 'Status', 'name', '公開・非公開', 2, 1, '2026-03-14 08:34:57', '2026-03-14 08:34:57', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (209, 6, NULL, 'Plugin\ProductReview42\Entity\ProductReview', 'create_date', 'create_date', '投稿日', 3, 1, '2026-03-14 08:34:57', '2026-03-14 08:34:57', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (210, 6, NULL, 'Plugin\ProductReview42\Entity\ProductReview', 'reviewer_name', 'reviewer_name', '投稿者名', 4, 1, '2026-03-14 08:34:57', '2026-03-14 08:34:57', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (211, 6, NULL, 'Plugin\ProductReview42\Entity\ProductReview', 'reviewer_url', 'reviewer_url', '投稿者URL', 5, 1, '2026-03-14 08:34:57', '2026-03-14 08:34:57', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (212, 6, NULL, 'Plugin\ProductReview42\Entity\ProductReview', 'Sex', 'name', '性別', 6, 1, '2026-03-14 08:34:57', '2026-03-14 08:34:57', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (213, 6, NULL, 'Plugin\ProductReview42\Entity\ProductReview', 'recommend_level', 'recommend_level', 'おすすめレベル', 7, 1, '2026-03-14 08:34:57', '2026-03-14 08:34:57', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (214, 6, NULL, 'Plugin\ProductReview42\Entity\ProductReview', 'title', 'title', 'タイトル', 8, 1, '2026-03-14 08:34:57', '2026-03-14 08:34:57', 'csv');
INSERT INTO dtb_csv (id, csv_type_id, creator_id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, discriminator_type) VALUES (215, 6, NULL, 'Plugin\ProductReview42\Entity\ProductReview', 'comment', 'comment', 'コメント', 9, 1, '2026-03-14 08:34:57', '2026-03-14 08:34:57', 'csv');

-- Table: dtb_customer

-- Table: dtb_customer_address

-- Table: dtb_customer_favorite_product

-- Table: dtb_delivery
INSERT INTO dtb_delivery (id, creator_id, sale_type_id, name, service_name, description, confirm_url, sort_no, visible, create_date, update_date, discriminator_type) VALUES (1, NULL, 1, 'サンプル業者', 'サンプル業者', NULL, NULL, 1, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'delivery');
INSERT INTO dtb_delivery (id, creator_id, sale_type_id, name, service_name, description, confirm_url, sort_no, visible, create_date, update_date, discriminator_type) VALUES (2, NULL, 2, 'サンプル宅配', 'サンプル宅配', NULL, NULL, 2, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'delivery');

-- Table: dtb_delivery_duration
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES (1, '即日', 0, 0, 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES (2, '1～2日後', 1, 1, 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES (3, '3～4日後', 3, 2, 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES (4, '1週間以降', 7, 3, 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES (5, '2週間以降', 14, 4, 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES (6, '3週間以降', 21, 5, 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES (7, '1ヶ月以降', 30, 6, 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES (8, '2ヶ月以降', 60, 7, 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES (9, 'お取り寄せ(商品入荷後)', -1, 8, 'deliveryduration');

-- Table: dtb_delivery_fee
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (1, 1, 1, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (2, 1, 2, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (3, 1, 3, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (4, 1, 4, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (5, 1, 5, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (6, 1, 6, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (7, 1, 7, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (8, 1, 8, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (9, 1, 9, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (10, 1, 10, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (11, 1, 11, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (12, 1, 12, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (13, 1, 13, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (14, 1, 14, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (15, 1, 15, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (16, 1, 16, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (17, 1, 17, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (18, 1, 18, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (19, 1, 19, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (20, 1, 20, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (21, 1, 21, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (22, 1, 22, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (23, 1, 23, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (24, 1, 24, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (25, 1, 25, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (26, 1, 26, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (27, 1, 27, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (28, 1, 28, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (29, 1, 29, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (30, 1, 30, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (31, 1, 31, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (32, 1, 32, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (33, 1, 33, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (34, 1, 34, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (35, 1, 35, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (36, 1, 36, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (37, 1, 37, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (38, 1, 38, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (39, 1, 39, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (40, 1, 40, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (41, 1, 41, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (42, 1, 42, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (43, 1, 43, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (44, 1, 44, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (45, 1, 45, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (46, 1, 46, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (47, 1, 47, 1000, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (48, 2, 1, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (49, 2, 2, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (50, 2, 3, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (51, 2, 4, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (52, 2, 5, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (53, 2, 6, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (54, 2, 7, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (55, 2, 8, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (56, 2, 9, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (57, 2, 10, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (58, 2, 11, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (59, 2, 12, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (60, 2, 13, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (61, 2, 14, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (62, 2, 15, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (63, 2, 16, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (64, 2, 17, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (65, 2, 18, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (66, 2, 19, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (67, 2, 20, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (68, 2, 21, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (69, 2, 22, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (70, 2, 23, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (71, 2, 24, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (72, 2, 25, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (73, 2, 26, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (74, 2, 27, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (75, 2, 28, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (76, 2, 29, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (77, 2, 30, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (78, 2, 31, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (79, 2, 32, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (80, 2, 33, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (81, 2, 34, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (82, 2, 35, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (83, 2, 36, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (84, 2, 37, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (85, 2, 38, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (86, 2, 39, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (87, 2, 40, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (88, 2, 41, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (89, 2, 42, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (90, 2, 43, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (91, 2, 44, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (92, 2, 45, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (93, 2, 46, 0, 'deliveryfee');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, fee, discriminator_type) VALUES (94, 2, 47, 0, 'deliveryfee');

-- Table: dtb_delivery_time
INSERT INTO dtb_delivery_time (id, delivery_id, delivery_time, sort_no, visible, create_date, update_date, discriminator_type) VALUES (1, 1, '午前', 1, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'deliverytime');
INSERT INTO dtb_delivery_time (id, delivery_id, delivery_time, sort_no, visible, create_date, update_date, discriminator_type) VALUES (2, 1, '午後', 2, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'deliverytime');

-- Table: dtb_layout
INSERT INTO dtb_layout (id, device_type_id, layout_name, create_date, update_date, discriminator_type) VALUES (0, 10, 'プレビュー用レイアウト', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'layout');
INSERT INTO dtb_layout (id, device_type_id, layout_name, create_date, update_date, discriminator_type) VALUES (1, 10, 'トップページ用レイアウト', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'layout');
INSERT INTO dtb_layout (id, device_type_id, layout_name, create_date, update_date, discriminator_type) VALUES (2, 10, '下層ページ用レイアウト', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'layout');

-- Table: dtb_login_history
INSERT INTO dtb_login_history (id, login_history_status_id, member_id, user_name, client_ip, create_date, update_date, discriminator_type) VALUES (1, 1, 1, 'admin', '169.150.207.210', '2026-03-14 08:29:39', '2026-03-14 08:29:39', 'loginhistory');

-- Table: dtb_mail_history

-- Table: dtb_mail_template
INSERT INTO dtb_mail_template (id, creator_id, name, file_name, mail_subject, create_date, update_date, discriminator_type) VALUES (1, NULL, '注文受付メール', 'Mail/order.twig', 'ご注文ありがとうございます', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'mailtemplate');
INSERT INTO dtb_mail_template (id, creator_id, name, file_name, mail_subject, create_date, update_date, discriminator_type) VALUES (2, NULL, '会員仮登録メール', 'Mail/entry_confirm.twig', '会員登録のご確認', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'mailtemplate');
INSERT INTO dtb_mail_template (id, creator_id, name, file_name, mail_subject, create_date, update_date, discriminator_type) VALUES (3, NULL, '会員本登録メール', 'Mail/entry_complete.twig', '会員登録が完了しました。', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'mailtemplate');
INSERT INTO dtb_mail_template (id, creator_id, name, file_name, mail_subject, create_date, update_date, discriminator_type) VALUES (4, NULL, '会員退会メール', 'Mail/customer_withdraw_mail.twig', '退会手続きのご完了', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'mailtemplate');
INSERT INTO dtb_mail_template (id, creator_id, name, file_name, mail_subject, create_date, update_date, discriminator_type) VALUES (5, NULL, '問合受付メール', 'Mail/contact_mail.twig', 'お問い合わせを受け付けました。', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'mailtemplate');
INSERT INTO dtb_mail_template (id, creator_id, name, file_name, mail_subject, create_date, update_date, discriminator_type) VALUES (6, NULL, 'パスワードリセット', 'Mail/forgot_mail.twig', 'パスワード変更のご確認', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'mailtemplate');
INSERT INTO dtb_mail_template (id, creator_id, name, file_name, mail_subject, create_date, update_date, discriminator_type) VALUES (7, NULL, 'パスワードリマインダー', 'Mail/reset_complete_mail.twig', 'パスワード変更のお知らせ', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'mailtemplate');
INSERT INTO dtb_mail_template (id, creator_id, name, file_name, mail_subject, create_date, update_date, discriminator_type) VALUES (8, NULL, '出荷通知メール', 'Mail/shipping_notify.twig', '商品出荷のお知らせ', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'mailtemplate');
INSERT INTO dtb_mail_template (id, creator_id, name, file_name, mail_subject, create_date, update_date, discriminator_type) VALUES (9, NULL, '会員情報変更通知メール', 'Mail/customer_change_notify.twig', '会員情報変更のお知らせ', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'mailtemplate');

-- Table: dtb_member
INSERT INTO dtb_member (id, work_id, authority_id, creator_id, name, department, login_id, password, salt, sort_no, two_factor_auth_key, two_factor_auth_enabled, create_date, update_date, login_date, discriminator_type) VALUES (1, 1, 0, 1, '管理者', 'EC-CUBE SHOP', 'admin', 'ae4d818cf2dc3dcaefd522dc7d6bf8ccc1e5ed3fb0cc26899f01511604399eb1', 'JjONVf12guadWHFnfYTknS3jpT10xXiT', 1, NULL, 0, '2026-03-14 08:24:50', '2026-03-14 08:29:39', '2026-03-14 08:29:39', 'member');

-- Table: dtb_news
INSERT INTO dtb_news (id, creator_id, publish_date, title, description, url, link_method, create_date, update_date, visible, discriminator_type) VALUES (1, NULL, '2018-09-01 09:00:00', 'サイトオープンいたしました!', '旬の色どりスイーツとこだわりのジェラートをお届けします。', NULL, 1, '2018-09-01 09:00:00', '2018-09-01 09:00:00', 1, 'news');

-- Table: dtb_order

-- Table: dtb_order_item

-- Table: dtb_order_pdf

-- Table: dtb_page
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (0, NULL, 'プレビューデータ', 'preview', NULL, 1, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (1, NULL, 'TOPページ', 'homepage', 'index', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (2, NULL, '商品一覧ページ', 'product_list', 'Product/list', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (3, NULL, '商品詳細ページ', 'product_detail', 'Product/detail', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (4, NULL, 'MYページ', 'mypage', 'Mypage/index', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (5, NULL, 'MYページ/会員登録内容変更(入力ページ)', 'mypage_change', 'Mypage/change', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (6, NULL, 'MYページ/会員登録内容変更(完了ページ)', 'mypage_change_complete', 'Mypage/change_complete', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (7, NULL, 'MYページ/お届け先一覧', 'mypage_delivery', 'Mypage/delivery', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (8, NULL, 'MYページ/お届け先追加', 'mypage_delivery_new', 'Mypage/delivery_edit', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (9, NULL, 'MYページ/お気に入り一覧', 'mypage_favorite', 'Mypage/favorite', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (10, NULL, 'MYページ/購入履歴詳細', 'mypage_history', 'Mypage/history', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (11, NULL, 'MYページ/ログイン', 'mypage_login', 'Mypage/login', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (12, NULL, 'MYページ/退会手続き(入力ページ)', 'mypage_withdraw', 'Mypage/withdraw', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (13, NULL, 'MYページ/退会手続き(完了ページ)', 'mypage_withdraw_complete', 'Mypage/withdraw_complete', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (14, NULL, '当サイトについて', 'help_about', 'Help/about', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (15, NULL, '現在のカゴの中', 'cart', 'Cart/index', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (16, NULL, 'お問い合わせ(入力ページ)', 'contact', 'Contact/index', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (17, NULL, 'お問い合わせ(完了ページ)', 'contact_complete', 'Contact/complete', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (18, NULL, '会員登録(入力ページ)', 'entry', 'Entry/index', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (19, NULL, 'ご利用規約', 'help_agreement', 'Help/agreement', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (20, NULL, '会員登録(完了ページ)', 'entry_complete', 'Entry/complete', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (21, NULL, '特定商取引に関する法律に基づく表記', 'help_tradelaw', 'Help/tradelaw', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (22, NULL, '本会員登録(完了ページ)', 'entry_activate', 'Entry/activate', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (23, NULL, '商品購入', 'shopping', 'Shopping/index', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (24, NULL, '商品購入/お届け先の指定', 'shopping_shipping', 'Shopping/shipping', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (25, NULL, '商品購入/お届け先の複数指定', 'shopping_shipping_multiple', 'Shopping/shipping_multiple', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (28, NULL, '商品購入/ご注文完了', 'shopping_complete', 'Shopping/complete', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (29, NULL, 'プライバシーポリシー', 'help_privacy', 'Help/privacy', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (30, NULL, '商品購入ログイン', 'shopping_login', 'Shopping/login', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (31, NULL, '非会員購入情報入力', 'shopping_nonmember', 'Shopping/nonmember', 2, NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (32, NULL, '商品購入/お届け先の追加', 'shopping_shipping_edit', 'Shopping/shipping_edit', 2, NULL, NULL, NULL, '2017-03-07 01:15:02', '2017-03-07 01:15:02', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (33, NULL, '商品購入/お届け先の複数指定(お届け先の追加)', 'shopping_shipping_multiple_edit', 'Shopping/shipping_multiple_edit', 2, NULL, NULL, NULL, '2017-03-07 01:15:02', '2017-03-07 01:15:02', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (34, NULL, '商品購入/購入エラー', 'shopping_error', 'Shopping/shopping_error', 2, NULL, NULL, NULL, '2017-03-07 01:15:02', '2017-03-07 01:15:02', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (35, NULL, 'ご利用ガイド', 'help_guide', 'Help/guide', 2, NULL, NULL, NULL, '2017-03-07 01:15:02', '2017-03-07 01:15:02', NULL, NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (36, NULL, 'パスワード再発行(入力ページ)', 'forgot', 'Forgot/index', 2, NULL, NULL, NULL, '2017-03-07 01:15:02', '2017-03-07 01:15:02', NULL, NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (37, NULL, 'パスワード再発行(完了ページ)', 'forgot_complete', 'Forgot/complete', 2, NULL, NULL, NULL, '2017-03-07 01:15:02', '2017-03-07 01:15:02', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (38, NULL, 'パスワード再発行(再設定ページ)', 'forgot_reset', 'Forgot/reset', 2, NULL, NULL, NULL, '2017-03-07 01:15:02', '2017-03-07 01:15:05', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (42, NULL, '商品購入/遷移', 'shopping_redirect_to', 'Shopping/index', 2, NULL, NULL, NULL, '2017-03-07 01:15:03', '2017-03-07 01:15:03', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (44, 8, 'MYページ/お届け先編集', 'mypage_delivery_edit', 'Mypage/delivery_edit', 2, NULL, NULL, NULL, '2017-03-07 01:15:05', '2017-03-07 01:15:05', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (45, NULL, '商品購入/ご注文確認', 'shopping_confirm', 'Shopping/confirm', 2, NULL, NULL, NULL, '2017-03-07 01:15:03', '2017-03-07 01:15:03', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (46, 18, '会員登録(確認ページ)', 'entry_confirm', 'Entry/confirm', 3, NULL, NULL, NULL, '2020-01-12 01:15:03', '2020-01-12 01:15:03', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (47, 12, 'MYページ/退会手続き(確認ページ)', 'mypage_withdraw_confirm', 'Mypage/withdraw_confirm', 3, NULL, NULL, NULL, '2020-01-12 10:14:52', '2020-01-12 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (48, 16, 'お問い合わせ(確認ページ)', 'contact_confirm', 'Contact/confirm', 3, NULL, NULL, NULL, '2020-01-12 10:14:52', '2020-01-12 10:14:52', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (49, NULL, '商品購入/クーポン利用', 'plugin_coupon_shopping', 'Coupon42/Resource/template/default/shopping_coupon', 2, NULL, NULL, NULL, '2026-03-14 08:34:07', '2026-03-14 08:34:07', 'noindex', NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (50, NULL, 'レビューを表示', 'product_review_display', 'ProductReview42/Resource/template/default/review', 2, NULL, NULL, NULL, '2026-03-14 08:34:57', '2026-03-14 08:34:57', NULL, NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (51, NULL, 'レビューを投稿', 'product_review_index', 'ProductReview42/Resource/template/default/index', 2, NULL, NULL, NULL, '2026-03-14 08:34:58', '2026-03-14 08:34:58', NULL, NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (52, NULL, 'レビューを投稿(確認)', 'product_review_confirm', 'ProductReview42/Resource/template/default/confirm', 2, NULL, NULL, NULL, '2026-03-14 08:34:58', '2026-03-14 08:34:58', NULL, NULL, 'page');
INSERT INTO dtb_page (id, master_page_id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, discriminator_type) VALUES (53, NULL, 'レビューを投稿(完了)', 'product_review_complete', 'ProductReview42/Resource/template/default/complete', 2, NULL, NULL, NULL, '2026-03-14 08:34:58', '2026-03-14 08:34:58', NULL, NULL, 'page');

-- Table: dtb_page_layout
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (0, 0, 2, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (1, 1, 2, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (2, 2, 4, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (3, 2, 5, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (4, 2, 6, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (5, 2, 7, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (6, 2, 8, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (9, 2, 9, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (10, 2, 10, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (11, 2, 11, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (12, 2, 12, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (14, 2, 13, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (13, 2, 14, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (15, 2, 15, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (16, 2, 16, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (17, 2, 17, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (18, 2, 18, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (20, 2, 19, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (21, 2, 20, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (22, 2, 21, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (24, 2, 22, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (28, 2, 23, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (29, 2, 24, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (30, 2, 25, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (31, 2, 26, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (32, 2, 27, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (33, 2, 28, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (34, 2, 29, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (35, 2, 30, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (36, 2, 31, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (37, 2, 32, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (19, 2, 33, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (25, 2, 34, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (23, 2, 35, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (7, 2, 36, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (8, 2, 37, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (42, 2, 38, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (38, 2, 39, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (44, 2, 40, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (45, 2, 41, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (46, 2, 42, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (47, 2, 43, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (48, 2, 44, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (49, 2, 0, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (50, 2, 0, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (51, 2, 0, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (52, 2, 0, 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES (53, 2, 0, 'pagelayout');

-- Table: dtb_payment
INSERT INTO dtb_payment (id, creator_id, payment_method, charge, rule_max, sort_no, fixed, payment_image, rule_min, method_class, visible, create_date, update_date, discriminator_type) VALUES (1, NULL, '郵便振替', 0, NULL, 4, 1, NULL, 0, 'Eccube\Service\Payment\Method\Cash', 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'payment');
INSERT INTO dtb_payment (id, creator_id, payment_method, charge, rule_max, sort_no, fixed, payment_image, rule_min, method_class, visible, create_date, update_date, discriminator_type) VALUES (2, NULL, '現金書留', 0, NULL, 3, 1, NULL, 0, 'Eccube\Service\Payment\Method\Cash', 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'payment');
INSERT INTO dtb_payment (id, creator_id, payment_method, charge, rule_max, sort_no, fixed, payment_image, rule_min, method_class, visible, create_date, update_date, discriminator_type) VALUES (3, NULL, '銀行振込', 0, NULL, 2, 1, NULL, 0, 'Eccube\Service\Payment\Method\Cash', 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'payment');
INSERT INTO dtb_payment (id, creator_id, payment_method, charge, rule_max, sort_no, fixed, payment_image, rule_min, method_class, visible, create_date, update_date, discriminator_type) VALUES (4, NULL, '代金引換', 0, NULL, 1, 1, NULL, 0, 'Eccube\Service\Payment\Method\Cash', 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'payment');

-- Table: dtb_payment_option
INSERT INTO dtb_payment_option (delivery_id, payment_id, discriminator_type) VALUES (1, 1, 'paymentoption');
INSERT INTO dtb_payment_option (delivery_id, payment_id, discriminator_type) VALUES (1, 2, 'paymentoption');
INSERT INTO dtb_payment_option (delivery_id, payment_id, discriminator_type) VALUES (1, 3, 'paymentoption');
INSERT INTO dtb_payment_option (delivery_id, payment_id, discriminator_type) VALUES (1, 4, 'paymentoption');
INSERT INTO dtb_payment_option (delivery_id, payment_id, discriminator_type) VALUES (2, 3, 'paymentoption');

-- Table: dtb_plugin
INSERT INTO dtb_plugin (id, name, code, enabled, version, source, initialized, create_date, update_date, discriminator_type) VALUES (1, 'おすすめ商品管理プラグイン', 'Recommend42', 1, '4.3.0', '2403', 1, '2021-08-13 00:00:00', '2026-03-14 08:35:19', 'plugin');
INSERT INTO dtb_plugin (id, name, code, enabled, version, source, initialized, create_date, update_date, discriminator_type) VALUES (2, 'Coupon Plugin for EC-CUBE42', 'Coupon42', 1, '4.3.0', '2401', 1, '2021-08-13 00:00:00', '2026-03-14 08:34:07', 'plugin');
INSERT INTO dtb_plugin (id, name, code, enabled, version, source, initialized, create_date, update_date, discriminator_type) VALUES (3, 'メールマガジンプラグイン', 'MailMagazine42', 1, '4.3.1', '2404', 1, '2021-08-13 00:00:00', '2026-03-14 08:34:36', 'plugin');
INSERT INTO dtb_plugin (id, name, code, enabled, version, source, initialized, create_date, update_date, discriminator_type) VALUES (4, '売上集計プラグイン', 'SalesReport42', 1, '4.3.0', '2406', 1, '2021-08-13 00:00:00', '2026-03-14 08:35:57', 'plugin');
INSERT INTO dtb_plugin (id, name, code, enabled, version, source, initialized, create_date, update_date, discriminator_type) VALUES (5, '関連商品プラグイン', 'RelatedProduct42', 1, '4.3.0', '2398', 1, '2021-08-13 00:00:00', '2026-03-14 08:35:37', 'plugin');
INSERT INTO dtb_plugin (id, name, code, enabled, version, source, initialized, create_date, update_date, discriminator_type) VALUES (6, 'Securitychecker42', 'Securitychecker42', 1, '4.3.1', '2402', 1, '2021-08-13 00:00:00', '2026-03-14 08:36:16', 'plugin');
INSERT INTO dtb_plugin (id, name, code, enabled, version, source, initialized, create_date, update_date, discriminator_type) VALUES (7, '商品レビュー管理プラグイン', 'ProductReview42', 1, '4.3.0', '2405', 1, '2021-08-13 00:00:00', '2026-03-14 08:34:58', 'plugin');
INSERT INTO dtb_plugin (id, name, code, enabled, version, source, initialized, create_date, update_date, discriminator_type) VALUES (8, 'Web API', 'Api42', 1, '4.3.2', '2400', 1, '2021-08-13 00:00:00', '2026-03-14 08:33:47', 'plugin');
INSERT INTO dtb_plugin (id, name, code, enabled, version, source, initialized, create_date, update_date, discriminator_type) VALUES (9, 'Site Kit プラグイン', 'SiteKit42', 1, '4.3.0', '2399', 1, '2021-08-13 00:00:00', '2026-03-14 08:36:42', 'plugin');
INSERT INTO dtb_plugin (id, name, code, enabled, version, source, initialized, create_date, update_date, discriminator_type) VALUES (10, 'データ移行向けバックアップ生成プラグイン for EC-CUBE 4', 'DataMigrationBackup42', 1, '1.0.10', '0', 1, '2026-03-14 08:34:12', '2026-03-14 08:34:15', 'plugin');

-- Table: dtb_product
INSERT INTO dtb_product (id, creator_id, product_status_id, name, note, description_list, description_detail, search_word, free_area, create_date, update_date, discriminator_type) VALUES (1, NULL, 1, '彩のジェラートCUBE', NULL, NULL, '冬でも食べたい立方体のジェラート。定番のチョコフレーバーは、チョコレート特有の甘い香りが特徴です。適度な甘みと日本人の口に合いやすいサイズ感で長く愛用いただけます。
最高級バニラフレーバーは、贈り物としても人気です。', NULL, NULL, '2018-09-28 10:14:52', '2018-09-28 10:14:52', 'product');
INSERT INTO dtb_product (id, creator_id, product_status_id, name, note, description_list, description_detail, search_word, free_area, create_date, update_date, discriminator_type) VALUES (2, NULL, 1, 'チェリーアイスサンド', NULL, NULL, 'チェリーアイスサンドは北海道産のチェリーのアイスをサクサクのクッキーでサンドしたスイーツです。立方体なので大量に持ち運ぶときも便利です。
いまだけ、頑丈な箱つきです。', NULL, NULL, '2018-09-28 10:14:52', '2018-09-28 10:14:52', 'product');

-- Table: dtb_product_category
INSERT INTO dtb_product_category (product_id, category_id, discriminator_type) VALUES (1, 1, 'productcategory');
INSERT INTO dtb_product_category (product_id, category_id, discriminator_type) VALUES (1, 2, 'productcategory');
INSERT INTO dtb_product_category (product_id, category_id, discriminator_type) VALUES (1, 3, 'productcategory');
INSERT INTO dtb_product_category (product_id, category_id, discriminator_type) VALUES (1, 4, 'productcategory');
INSERT INTO dtb_product_category (product_id, category_id, discriminator_type) VALUES (2, 2, 'productcategory');
INSERT INTO dtb_product_category (product_id, category_id, discriminator_type) VALUES (2, 5, 'productcategory');
INSERT INTO dtb_product_category (product_id, category_id, discriminator_type) VALUES (2, 6, 'productcategory');

-- Table: dtb_product_class
INSERT INTO dtb_product_class (id, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, product_code, stock, stock_unlimited, sale_limit, price01, price02, delivery_fee, visible, create_date, update_date, currency_code, point_rate, discriminator_type) VALUES (1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 115000, 110000, NULL, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', NULL, 'productclass');
INSERT INTO dtb_product_class (id, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, product_code, stock, stock_unlimited, sale_limit, price01, price02, delivery_fee, visible, create_date, update_date, currency_code, point_rate, discriminator_type) VALUES (2, 1, 1, 3, 6, NULL, NULL, 'cube-01', NULL, 1, NULL, 115000, 110000, NULL, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', NULL, 'productclass');
INSERT INTO dtb_product_class (id, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, product_code, stock, stock_unlimited, sale_limit, price01, price02, delivery_fee, visible, create_date, update_date, currency_code, point_rate, discriminator_type) VALUES (3, 1, 1, 3, 5, NULL, NULL, 'cube-02', NULL, 1, NULL, 95000, 93000, NULL, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', NULL, 'productclass');
INSERT INTO dtb_product_class (id, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, product_code, stock, stock_unlimited, sale_limit, price01, price02, delivery_fee, visible, create_date, update_date, currency_code, point_rate, discriminator_type) VALUES (4, 1, 1, 3, 4, NULL, NULL, 'cube-03', NULL, 1, NULL, 75000, 74000, NULL, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', NULL, 'productclass');
INSERT INTO dtb_product_class (id, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, product_code, stock, stock_unlimited, sale_limit, price01, price02, delivery_fee, visible, create_date, update_date, currency_code, point_rate, discriminator_type) VALUES (5, 1, 1, 2, 6, NULL, NULL, 'cube-04', NULL, 1, NULL, 95000, 93000, NULL, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', NULL, 'productclass');
INSERT INTO dtb_product_class (id, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, product_code, stock, stock_unlimited, sale_limit, price01, price02, delivery_fee, visible, create_date, update_date, currency_code, point_rate, discriminator_type) VALUES (6, 1, 1, 2, 5, NULL, NULL, 'cube-05', NULL, 1, NULL, 50000, 49000, NULL, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', NULL, 'productclass');
INSERT INTO dtb_product_class (id, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, product_code, stock, stock_unlimited, sale_limit, price01, price02, delivery_fee, visible, create_date, update_date, currency_code, point_rate, discriminator_type) VALUES (7, 1, 1, 2, 4, NULL, NULL, 'cube-06', NULL, 1, NULL, 35000, 34500, NULL, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', NULL, 'productclass');
INSERT INTO dtb_product_class (id, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, product_code, stock, stock_unlimited, sale_limit, price01, price02, delivery_fee, visible, create_date, update_date, currency_code, point_rate, discriminator_type) VALUES (8, 1, 1, 1, 6, NULL, NULL, 'cube-07', NULL, 1, NULL, NULL, 18000, NULL, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', NULL, 'productclass');
INSERT INTO dtb_product_class (id, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, product_code, stock, stock_unlimited, sale_limit, price01, price02, delivery_fee, visible, create_date, update_date, currency_code, point_rate, discriminator_type) VALUES (9, 1, 1, 1, 5, NULL, NULL, 'cube-08', NULL, 1, NULL, NULL, 13000, NULL, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', NULL, 'productclass');
INSERT INTO dtb_product_class (id, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, product_code, stock, stock_unlimited, sale_limit, price01, price02, delivery_fee, visible, create_date, update_date, currency_code, point_rate, discriminator_type) VALUES (10, 1, 1, 1, 4, NULL, NULL, 'cube-09', NULL, 1, NULL, NULL, 5000, NULL, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', NULL, 'productclass');
INSERT INTO dtb_product_class (id, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, product_code, stock, stock_unlimited, sale_limit, price01, price02, delivery_fee, visible, create_date, update_date, currency_code, point_rate, discriminator_type) VALUES (11, 2, 1, NULL, NULL, NULL, NULL, 'sand-01', 100, 0, 5, 3000, 2800, NULL, 1, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', NULL, 'productclass');

-- Table: dtb_product_image
INSERT INTO dtb_product_image (id, product_id, creator_id, file_name, sort_no, create_date, discriminator_type) VALUES (1, 1, NULL, 'cube-1.png', 1, '2017-03-07 10:14:52', 'productimage');
INSERT INTO dtb_product_image (id, product_id, creator_id, file_name, sort_no, create_date, discriminator_type) VALUES (2, 1, NULL, 'cube-2.png', 2, '2017-03-07 10:14:52', 'productimage');
INSERT INTO dtb_product_image (id, product_id, creator_id, file_name, sort_no, create_date, discriminator_type) VALUES (3, 1, NULL, 'cube-3.png', 3, '2017-03-07 10:14:52', 'productimage');
INSERT INTO dtb_product_image (id, product_id, creator_id, file_name, sort_no, create_date, discriminator_type) VALUES (4, 2, NULL, 'sand-1.png', 1, '2017-03-07 10:14:52', 'productimage');
INSERT INTO dtb_product_image (id, product_id, creator_id, file_name, sort_no, create_date, discriminator_type) VALUES (5, 2, NULL, 'sand-2.png', 2, '2017-03-07 10:14:52', 'productimage');
INSERT INTO dtb_product_image (id, product_id, creator_id, file_name, sort_no, create_date, discriminator_type) VALUES (6, 2, NULL, 'sand-3.png', 3, '2017-03-07 10:14:52', 'productimage');

-- Table: dtb_product_stock
INSERT INTO dtb_product_stock (id, product_class_id, creator_id, stock, create_date, update_date, discriminator_type) VALUES (1, 1, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'productstock');
INSERT INTO dtb_product_stock (id, product_class_id, creator_id, stock, create_date, update_date, discriminator_type) VALUES (2, 2, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'productstock');
INSERT INTO dtb_product_stock (id, product_class_id, creator_id, stock, create_date, update_date, discriminator_type) VALUES (3, 3, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'productstock');
INSERT INTO dtb_product_stock (id, product_class_id, creator_id, stock, create_date, update_date, discriminator_type) VALUES (4, 4, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'productstock');
INSERT INTO dtb_product_stock (id, product_class_id, creator_id, stock, create_date, update_date, discriminator_type) VALUES (5, 5, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'productstock');
INSERT INTO dtb_product_stock (id, product_class_id, creator_id, stock, create_date, update_date, discriminator_type) VALUES (6, 6, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'productstock');
INSERT INTO dtb_product_stock (id, product_class_id, creator_id, stock, create_date, update_date, discriminator_type) VALUES (7, 7, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'productstock');
INSERT INTO dtb_product_stock (id, product_class_id, creator_id, stock, create_date, update_date, discriminator_type) VALUES (8, 8, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'productstock');
INSERT INTO dtb_product_stock (id, product_class_id, creator_id, stock, create_date, update_date, discriminator_type) VALUES (9, 9, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'productstock');
INSERT INTO dtb_product_stock (id, product_class_id, creator_id, stock, create_date, update_date, discriminator_type) VALUES (10, 10, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'productstock');
INSERT INTO dtb_product_stock (id, product_class_id, creator_id, stock, create_date, update_date, discriminator_type) VALUES (11, 11, NULL, 100, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'productstock');

-- Table: dtb_product_tag

-- Table: dtb_shipping

-- Table: dtb_tag
INSERT INTO dtb_tag (id, name, sort_no, discriminator_type) VALUES (1, '新商品', 1, 'tag');
INSERT INTO dtb_tag (id, name, sort_no, discriminator_type) VALUES (2, 'おすすめ商品', 2, 'tag');
INSERT INTO dtb_tag (id, name, sort_no, discriminator_type) VALUES (3, '限定品', 3, 'tag');

-- Table: dtb_tax_rule
INSERT INTO dtb_tax_rule (id, product_class_id, creator_id, country_id, pref_id, product_id, rounding_type_id, tax_rate, tax_adjust, apply_date, create_date, update_date, discriminator_type) VALUES (1, NULL, NULL, NULL, NULL, NULL, 1, 10, 0, '2017-03-07 10:14:52', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'taxrule');

-- Table: dtb_template
INSERT INTO dtb_template (id, device_type_id, template_code, template_name, create_date, update_date, discriminator_type) VALUES (1, 10, 'default', 'デフォルト', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'template');

-- Table: dtb_tradelaw
INSERT INTO dtb_tradelaw (id, name, description, sort_no, display_order_screen, discriminator_type) VALUES (1, '販売業者', NULL, 1, 0, 'tradelaw');
INSERT INTO dtb_tradelaw (id, name, description, sort_no, display_order_screen, discriminator_type) VALUES (2, '代表責任者', NULL, 2, 0, 'tradelaw');
INSERT INTO dtb_tradelaw (id, name, description, sort_no, display_order_screen, discriminator_type) VALUES (3, '所在地', NULL, 3, 0, 'tradelaw');
INSERT INTO dtb_tradelaw (id, name, description, sort_no, display_order_screen, discriminator_type) VALUES (4, '電話番号', NULL, 4, 0, 'tradelaw');
INSERT INTO dtb_tradelaw (id, name, description, sort_no, display_order_screen, discriminator_type) VALUES (5, 'メールアドレス', NULL, 5, 0, 'tradelaw');
INSERT INTO dtb_tradelaw (id, name, description, sort_no, display_order_screen, discriminator_type) VALUES (6, 'URL', NULL, 6, 0, 'tradelaw');
INSERT INTO dtb_tradelaw (id, name, description, sort_no, display_order_screen, discriminator_type) VALUES (7, '商品代金以外の必要料金', NULL, 7, 0, 'tradelaw');
INSERT INTO dtb_tradelaw (id, name, description, sort_no, display_order_screen, discriminator_type) VALUES (8, '引き渡し時期', NULL, 8, 0, 'tradelaw');
INSERT INTO dtb_tradelaw (id, name, description, sort_no, display_order_screen, discriminator_type) VALUES (9, 'お支払方法', NULL, 9, 0, 'tradelaw');
INSERT INTO dtb_tradelaw (id, name, description, sort_no, display_order_screen, discriminator_type) VALUES (10, '返品・交換について', NULL, 10, 0, 'tradelaw');
INSERT INTO dtb_tradelaw (id, name, description, sort_no, display_order_screen, discriminator_type) VALUES (11, NULL, NULL, 11, 0, 'tradelaw');
INSERT INTO dtb_tradelaw (id, name, description, sort_no, display_order_screen, discriminator_type) VALUES (12, NULL, NULL, 12, 0, 'tradelaw');
INSERT INTO dtb_tradelaw (id, name, description, sort_no, display_order_screen, discriminator_type) VALUES (13, NULL, NULL, 13, 0, 'tradelaw');
INSERT INTO dtb_tradelaw (id, name, description, sort_no, display_order_screen, discriminator_type) VALUES (14, NULL, NULL, 14, 0, 'tradelaw');
INSERT INTO dtb_tradelaw (id, name, description, sort_no, display_order_screen, discriminator_type) VALUES (15, NULL, NULL, 15, 0, 'tradelaw');

-- Table: mtb_authority
INSERT INTO mtb_authority (id, name, sort_no, discriminator_type) VALUES (0, 'システム管理者', 0, 'authority');
INSERT INTO mtb_authority (id, name, sort_no, discriminator_type) VALUES (1, '店舗オーナー', 1, 'authority');

-- Table: mtb_country
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (352, 'アイスランド', 1, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (372, 'アイルランド', 2, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (31, 'アゼルバイジャン', 3, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (4, 'アフガニスタン', 4, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (840, 'アメリカ合衆国', 5, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (850, 'アメリカ領ヴァージン諸島', 6, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (16, 'アメリカ領サモア', 7, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (784, 'アラブ首長国連邦', 8, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (12, 'アルジェリア', 9, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (32, 'アルゼンチン', 10, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (533, 'アルバ', 11, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (8, 'アルバニア', 12, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (51, 'アルメニア', 13, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (660, 'アンギラ', 14, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (24, 'アンゴラ', 15, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (28, 'アンティグア・バーブーダ', 16, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (20, 'アンドラ', 17, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (887, 'イエメン', 18, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (826, 'イギリス', 19, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (86, 'イギリス領インド洋地域', 20, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (92, 'イギリス領ヴァージン諸島', 21, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (376, 'イスラエル', 22, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (380, 'イタリア', 23, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (368, 'イラク', 24, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (364, 'イラン|イラン・イスラム共和国', 25, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (356, 'インド', 26, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (360, 'インドネシア', 27, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (876, 'ウォリス・フツナ', 28, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (800, 'ウガンダ', 29, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (804, 'ウクライナ', 30, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (860, 'ウズベキスタン', 31, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (858, 'ウルグアイ', 32, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (218, 'エクアドル', 33, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (818, 'エジプト', 34, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (233, 'エストニア', 35, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (231, 'エチオピア', 36, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (232, 'エリトリア', 37, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (222, 'エルサルバドル', 38, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (36, 'オーストラリア', 39, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (40, 'オーストリア', 40, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (248, 'オーランド諸島', 41, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (512, 'オマーン', 42, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (528, 'オランダ', 43, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (288, 'ガーナ', 44, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (132, 'カーボベルデ', 45, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (831, 'ガーンジー', 46, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (328, 'ガイアナ', 47, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (398, 'カザフスタン', 48, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (634, 'カタール', 49, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (581, '合衆国領有小離島', 50, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (124, 'カナダ', 51, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (266, 'ガボン', 52, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (120, 'カメルーン', 53, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (270, 'ガンビア', 54, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (116, 'カンボジア', 55, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (580, '北マリアナ諸島', 56, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (324, 'ギニア', 57, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (624, 'ギニアビサウ', 58, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (196, 'キプロス', 59, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (192, 'キューバ', 60, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (531, 'キュラソー島|キュラソー', 61, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (300, 'ギリシャ', 62, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (296, 'キリバス', 63, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (417, 'キルギス', 64, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (320, 'グアテマラ', 65, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (312, 'グアドループ', 66, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (316, 'グアム', 67, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (414, 'クウェート', 68, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (184, 'クック諸島', 69, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (304, 'グリーンランド', 70, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (162, 'クリスマス島 (オーストラリア)|クリスマス島', 71, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (268, 'グルジア', 72, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (308, 'グレナダ', 73, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (191, 'クロアチア', 74, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (136, 'ケイマン諸島', 75, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (404, 'ケニア', 76, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (384, 'コートジボワール', 77, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (166, 'ココス諸島|ココス（キーリング）諸島', 78, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (188, 'コスタリカ', 79, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (174, 'コモロ', 80, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (170, 'コロンビア', 81, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (178, 'コンゴ共和国', 82, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (180, 'コンゴ民主共和国', 83, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (682, 'サウジアラビア', 84, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (239, 'サウスジョージア・サウスサンドウィッチ諸島', 85, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (882, 'サモア', 86, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (678, 'サントメ・プリンシペ', 87, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (652, 'サン・バルテルミー島|サン・バルテルミー', 88, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (894, 'ザンビア', 89, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (666, 'サンピエール島・ミクロン島', 90, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (674, 'サンマリノ', 91, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (663, 'サン・マルタン (西インド諸島)|サン・マルタン（フランス領）', 92, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (694, 'シエラレオネ', 93, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (262, 'ジブチ', 94, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (292, 'ジブラルタル', 95, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (832, 'ジャージー', 96, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (388, 'ジャマイカ', 97, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (760, 'シリア|シリア・アラブ共和国', 98, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (702, 'シンガポール', 99, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (534, 'シント・マールテン|シント・マールテン（オランダ領）', 100, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (716, 'ジンバブエ', 101, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (756, 'スイス', 102, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (752, 'スウェーデン', 103, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (729, 'スーダン', 104, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (744, 'スヴァールバル諸島およびヤンマイエン島', 105, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (724, 'スペイン', 106, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (740, 'スリナム', 107, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (144, 'スリランカ', 108, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (703, 'スロバキア', 109, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (705, 'スロベニア', 110, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (748, 'スワジランド', 111, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (690, 'セーシェル', 112, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (226, '赤道ギニア', 113, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (686, 'セネガル', 114, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (688, 'セルビア', 115, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (659, 'セントクリストファー・ネイビス', 116, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (670, 'セントビンセント・グレナディーン|セントビンセントおよびグレナディーン諸島', 117, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (426, 'レソト', 246, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (654, 'セントヘレナ・アセンションおよびトリスタンダクーニャ', 118, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (662, 'セントルシア', 119, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (706, 'ソマリア', 120, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (90, 'ソロモン諸島', 121, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (796, 'タークス・カイコス諸島', 122, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (764, 'タイ王国|タイ', 123, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (410, '大韓民国', 124, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (158, '台湾', 125, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (762, 'タジキスタン', 126, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (834, 'タンザニア', 127, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (203, 'チェコ', 128, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (148, 'チャド', 129, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (140, '中央アフリカ共和国', 130, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (156, '中華人民共和国|中国', 131, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (788, 'チュニジア', 132, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (408, '朝鮮民主主義人民共和国', 133, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (152, 'チリ', 134, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (798, 'ツバル', 135, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (208, 'デンマーク', 136, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (276, 'ドイツ', 137, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (768, 'トーゴ', 138, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (772, 'トケラウ', 139, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (214, 'ドミニカ共和国', 140, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (212, 'ドミニカ国', 141, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (780, 'トリニダード・トバゴ', 142, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (795, 'トルクメニスタン', 143, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (792, 'トルコ', 144, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (776, 'トンガ', 145, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (566, 'ナイジェリア', 146, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (520, 'ナウル', 147, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (516, 'ナミビア', 148, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (10, '南極', 149, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (570, 'ニウエ', 150, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (558, 'ニカラグア', 151, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (562, 'ニジェール', 152, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (392, '日本', 153, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (732, '西サハラ', 154, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (540, 'ニューカレドニア', 155, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (554, 'ニュージーランド', 156, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (524, 'ネパール', 157, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (574, 'ノーフォーク島', 158, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (578, 'ノルウェー', 159, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (334, 'ハード島とマクドナルド諸島', 160, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (48, 'バーレーン', 161, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (332, 'ハイチ', 162, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (586, 'パキスタン', 163, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (336, 'バチカン|バチカン市国', 164, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (591, 'パナマ', 165, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (548, 'バヌアツ', 166, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (44, 'バハマ', 167, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (598, 'パプアニューギニア', 168, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (60, 'バミューダ諸島|バミューダ', 169, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (585, 'パラオ', 170, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (600, 'パラグアイ', 171, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (52, 'バルバドス', 172, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (275, 'パレスチナ', 173, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (348, 'ハンガリー', 174, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (50, 'バングラデシュ', 175, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (626, '東ティモール', 176, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (612, 'ピトケアン諸島|ピトケアン', 177, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (242, 'フィジー', 178, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (608, 'フィリピン', 179, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (246, 'フィンランド', 180, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (64, 'ブータン', 181, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (74, 'ブーベ島', 182, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (630, 'プエルトリコ', 183, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (234, 'フェロー諸島', 184, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (238, 'フォークランド諸島|フォークランド（マルビナス）諸島', 185, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (76, 'ブラジル', 186, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (250, 'フランス', 187, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (254, 'フランス領ギアナ', 188, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (258, 'フランス領ポリネシア', 189, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (260, 'フランス領南方・南極地域', 190, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (100, 'ブルガリア', 191, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (854, 'ブルキナファソ', 192, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (96, 'ブルネイ|ブルネイ・ダルサラーム', 193, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (108, 'ブルンジ', 194, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (704, 'ベトナム', 195, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (204, 'ベナン', 196, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (862, 'ベネズエラ|ベネズエラ・ボリバル共和国', 197, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (112, 'ベラルーシ', 198, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (84, 'ベリーズ', 199, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (604, 'ペルー', 200, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (56, 'ベルギー', 201, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (616, 'ポーランド', 202, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (70, 'ボスニア・ヘルツェゴビナ', 203, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (72, 'ボツワナ', 204, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (535, 'BES諸島|ボネール、シント・ユースタティウスおよびサバ', 205, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (68, 'ボリビア|ボリビア多民族国', 206, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (620, 'ポルトガル', 207, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (344, '香港', 208, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (340, 'ホンジュラス', 209, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (584, 'マーシャル諸島', 210, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (446, 'マカオ', 211, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (807, 'マケドニア共和国|マケドニア旧ユーゴスラビア共和国', 212, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (450, 'マダガスカル', 213, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (175, 'マヨット', 214, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (454, 'マラウイ', 215, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (466, 'マリ共和国|マリ', 216, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (470, 'マルタ', 217, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (474, 'マルティニーク', 218, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (458, 'マレーシア', 219, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (833, 'マン島', 220, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (583, 'ミクロネシア連邦', 221, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (710, '南アフリカ共和国|南アフリカ', 222, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (728, '南スーダン', 223, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (104, 'ミャンマー', 224, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (484, 'メキシコ', 225, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (480, 'モーリシャス', 226, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (478, 'モーリタニア', 227, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (508, 'モザンビーク', 228, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (492, 'モナコ', 229, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (462, 'モルディブ', 230, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (498, 'モルドバ|モルドバ共和国', 231, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (504, 'モロッコ', 232, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (496, 'モンゴル国|モンゴル', 233, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (499, 'モンテネグロ', 234, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (500, 'モントセラト', 235, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (400, 'ヨルダン', 236, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (418, 'ラオス|ラオス人民民主共和国', 237, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (428, 'ラトビア', 238, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (440, 'リトアニア', 239, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (434, 'リビア', 240, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (438, 'リヒテンシュタイン', 241, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (430, 'リベリア', 242, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (642, 'ルーマニア', 243, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (442, 'ルクセンブルク', 244, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (646, 'ルワンダ', 245, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (422, 'レバノン', 247, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (638, 'レユニオン', 248, 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES (643, 'ロシア|ロシア連邦', 249, 'country');

-- Table: mtb_csv_type
INSERT INTO mtb_csv_type (id, name, sort_no, discriminator_type) VALUES (1, '商品CSV', 3, 'csvtype');
INSERT INTO mtb_csv_type (id, name, sort_no, discriminator_type) VALUES (2, '会員CSV', 4, 'csvtype');
INSERT INTO mtb_csv_type (id, name, sort_no, discriminator_type) VALUES (3, '受注CSV', 1, 'csvtype');
INSERT INTO mtb_csv_type (id, name, sort_no, discriminator_type) VALUES (4, '配送CSV', 1, 'csvtype');
INSERT INTO mtb_csv_type (id, name, sort_no, discriminator_type) VALUES (5, 'カテゴリCSV', 5, 'csvtype');
INSERT INTO mtb_csv_type (id, name, sort_no, discriminator_type) VALUES (6, '商品レビューCSV', 6, 'csvtype');

-- Table: mtb_customer_order_status
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES (1, '注文受付', 0, 'customerorderstatus');
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES (3, '注文取消し', 4, 'customerorderstatus');
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES (4, '注文受付', 3, 'customerorderstatus');
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES (5, '発送済み', 6, 'customerorderstatus');
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES (6, '注文受付', 2, 'customerorderstatus');
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES (7, '注文受付', 1, 'customerorderstatus');
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES (8, '注文未完了', 5, 'customerorderstatus');
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES (9, '返品', 7, 'customerorderstatus');

-- Table: mtb_customer_status
INSERT INTO mtb_customer_status (id, name, sort_no, discriminator_type) VALUES (1, '仮会員', 0, 'customerstatus');
INSERT INTO mtb_customer_status (id, name, sort_no, discriminator_type) VALUES (2, '本会員', 1, 'customerstatus');
INSERT INTO mtb_customer_status (id, name, sort_no, discriminator_type) VALUES (3, '退会', 2, 'customerstatus');

-- Table: mtb_device_type
INSERT INTO mtb_device_type (id, name, sort_no, discriminator_type) VALUES (2, 'モバイル', 0, 'devicetype');
INSERT INTO mtb_device_type (id, name, sort_no, discriminator_type) VALUES (10, 'PC', 1, 'devicetype');

-- Table: mtb_job
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (1, '公務員', 0, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (2, 'コンサルタント', 1, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (3, 'コンピューター関連技術職', 2, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (4, 'コンピューター関連以外の技術職', 3, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (5, '金融関係', 4, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (6, '医師', 5, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (7, '弁護士', 6, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (8, '総務・人事・事務', 7, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (9, '営業・販売', 8, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (10, '研究・開発', 9, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (11, '広報・宣伝', 10, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (12, '企画・マーケティング', 11, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (13, 'デザイン関係', 12, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (14, '会社経営・役員', 13, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (15, '出版・マスコミ関係', 14, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (16, '学生・フリーター', 15, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (17, '主婦', 16, 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES (18, 'その他', 17, 'job');

-- Table: mtb_login_history_status
INSERT INTO mtb_login_history_status (id, name, sort_no, discriminator_type) VALUES (0, '失敗', 0, 'loginhistorystatus');
INSERT INTO mtb_login_history_status (id, name, sort_no, discriminator_type) VALUES (1, '成功', 1, 'loginhistorystatus');

-- Table: mtb_order_item_type
INSERT INTO mtb_order_item_type (id, name, sort_no, discriminator_type) VALUES (1, '商品', 0, 'orderitemtype');
INSERT INTO mtb_order_item_type (id, name, sort_no, discriminator_type) VALUES (2, '送料', 1, 'orderitemtype');
INSERT INTO mtb_order_item_type (id, name, sort_no, discriminator_type) VALUES (3, '手数料', 2, 'orderitemtype');
INSERT INTO mtb_order_item_type (id, name, sort_no, discriminator_type) VALUES (4, '割引', 3, 'orderitemtype');
INSERT INTO mtb_order_item_type (id, name, sort_no, discriminator_type) VALUES (5, '税', 4, 'orderitemtype');
INSERT INTO mtb_order_item_type (id, name, sort_no, discriminator_type) VALUES (6, 'ポイント', 5, 'orderitemtype');

-- Table: mtb_order_status
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES (1, 1, '新規受付', 0, 'orderstatus');
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES (3, 0, '注文取消し', 3, 'orderstatus');
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES (4, 1, '対応中', 2, 'orderstatus');
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES (5, 0, '発送済み', 4, 'orderstatus');
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES (6, 1, '入金済み', 1, 'orderstatus');
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES (7, 0, '決済処理中', 6, 'orderstatus');
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES (8, 0, '購入処理中', 5, 'orderstatus');
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES (9, 0, '返品', 7, 'orderstatus');

-- Table: mtb_order_status_color
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES (1, '#437ec4', 0, 'orderstatuscolor');
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES (3, '#C04949', 3, 'orderstatuscolor');
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES (4, '#EEB128', 2, 'orderstatuscolor');
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES (5, '#25B877', 4, 'orderstatuscolor');
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES (6, '#25B877', 1, 'orderstatuscolor');
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES (7, '#A3A3A3', 6, 'orderstatuscolor');
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES (8, '#A3A3A3', 5, 'orderstatuscolor');
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES (9, '#C04949', 7, 'orderstatuscolor');

-- Table: mtb_page_max
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES (10, '10', 0, 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES (20, '20', 1, 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES (30, '30', 2, 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES (40, '40', 3, 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES (50, '50', 4, 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES (60, '60', 5, 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES (70, '70', 6, 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES (80, '80', 7, 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES (90, '90', 8, 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES (100, '100', 9, 'pagemax');

-- Table: mtb_pref
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (1, '北海道', 1, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (2, '青森県', 2, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (3, '岩手県', 3, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (4, '宮城県', 4, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (5, '秋田県', 5, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (6, '山形県', 6, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (7, '福島県', 7, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (8, '茨城県', 8, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (9, '栃木県', 9, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (10, '群馬県', 10, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (11, '埼玉県', 11, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (12, '千葉県', 12, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (13, '東京都', 13, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (14, '神奈川県', 14, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (15, '新潟県', 15, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (16, '富山県', 16, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (17, '石川県', 17, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (18, '福井県', 18, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (19, '山梨県', 19, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (20, '長野県', 20, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (21, '岐阜県', 21, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (22, '静岡県', 22, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (23, '愛知県', 23, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (24, '三重県', 24, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (25, '滋賀県', 25, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (26, '京都府', 26, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (27, '大阪府', 27, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (28, '兵庫県', 28, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (29, '奈良県', 29, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (30, '和歌山県', 30, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (31, '鳥取県', 31, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (32, '島根県', 32, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (33, '岡山県', 33, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (34, '広島県', 34, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (35, '山口県', 35, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (36, '徳島県', 36, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (37, '香川県', 37, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (38, '愛媛県', 38, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (39, '高知県', 39, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (40, '福岡県', 40, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (41, '佐賀県', 41, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (42, '長崎県', 42, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (43, '熊本県', 43, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (44, '大分県', 44, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (45, '宮崎県', 45, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (46, '鹿児島県', 46, 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES (47, '沖縄県', 47, 'pref');

-- Table: mtb_product_list_max
INSERT INTO mtb_product_list_max (id, name, sort_no, discriminator_type) VALUES (20, '20件', 0, 'productlistmax');
INSERT INTO mtb_product_list_max (id, name, sort_no, discriminator_type) VALUES (40, '40件', 1, 'productlistmax');
INSERT INTO mtb_product_list_max (id, name, sort_no, discriminator_type) VALUES (60, '60件', 2, 'productlistmax');

-- Table: mtb_product_list_order_by
INSERT INTO mtb_product_list_order_by (id, name, sort_no, discriminator_type) VALUES (1, '価格が低い順', 0, 'productlistorderby');
INSERT INTO mtb_product_list_order_by (id, name, sort_no, discriminator_type) VALUES (2, '新着順', 2, 'productlistorderby');
INSERT INTO mtb_product_list_order_by (id, name, sort_no, discriminator_type) VALUES (3, '価格が高い順', 1, 'productlistorderby');

-- Table: mtb_product_status
INSERT INTO mtb_product_status (id, name, sort_no, discriminator_type) VALUES (1, '公開', 0, 'productstatus');
INSERT INTO mtb_product_status (id, name, sort_no, discriminator_type) VALUES (2, '非公開', 1, 'productstatus');
INSERT INTO mtb_product_status (id, name, sort_no, discriminator_type) VALUES (3, '廃止', 2, 'productstatus');

-- Table: mtb_rounding_type
INSERT INTO mtb_rounding_type (id, name, sort_no, discriminator_type) VALUES (1, '四捨五入', 0, 'roundingtype');
INSERT INTO mtb_rounding_type (id, name, sort_no, discriminator_type) VALUES (2, '切り捨て', 1, 'roundingtype');
INSERT INTO mtb_rounding_type (id, name, sort_no, discriminator_type) VALUES (3, '切り上げ', 2, 'roundingtype');

-- Table: mtb_sale_type
INSERT INTO mtb_sale_type (id, name, sort_no, discriminator_type) VALUES (1, '販売種別A', 0, 'saletype');
INSERT INTO mtb_sale_type (id, name, sort_no, discriminator_type) VALUES (2, '販売種別B', 1, 'saletype');

-- Table: mtb_sex
INSERT INTO mtb_sex (id, name, sort_no, discriminator_type) VALUES (1, '男性', 0, 'sex');
INSERT INTO mtb_sex (id, name, sort_no, discriminator_type) VALUES (2, '女性', 1, 'sex');
INSERT INTO mtb_sex (id, name, sort_no, discriminator_type) VALUES (3, 'その他', 2, 'sex');
INSERT INTO mtb_sex (id, name, sort_no, discriminator_type) VALUES (4, '回答しない', 3, 'sex');

-- Table: mtb_tax_display_type
INSERT INTO mtb_tax_display_type (id, name, sort_no, discriminator_type) VALUES (1, '税抜', 0, 'taxdisplaytype');
INSERT INTO mtb_tax_display_type (id, name, sort_no, discriminator_type) VALUES (2, '税込', 1, 'taxdisplaytype');

-- Table: mtb_tax_type
INSERT INTO mtb_tax_type (id, name, sort_no, discriminator_type) VALUES (1, '課税', 0, 'taxtype');
INSERT INTO mtb_tax_type (id, name, sort_no, discriminator_type) VALUES (2, '不課税', 1, 'taxtype');
INSERT INTO mtb_tax_type (id, name, sort_no, discriminator_type) VALUES (3, '非課税', 2, 'taxtype');

-- Table: mtb_work
INSERT INTO mtb_work (id, name, sort_no, discriminator_type) VALUES (0, '非稼働', 0, 'work');
INSERT INTO mtb_work (id, name, sort_no, discriminator_type) VALUES (1, '稼働', 1, 'work');

-- Table: oauth2_access_token

-- Table: oauth2_authorization_code

-- Table: oauth2_client

-- Table: oauth2_refresh_token

-- Table: plg_Securitychecker4_config

-- Table: plg_api_webhook

-- Table: plg_coupon

-- Table: plg_coupon_detail

-- Table: plg_coupon_order

-- Table: plg_mailmaga_send_history

-- Table: plg_mailmaga_template

-- Table: plg_product_review

-- Table: plg_product_review_config
INSERT INTO plg_product_review_config (id, csv_type_id, review_max, create_date, update_date) VALUES (1, 6, 5, '2026-03-14 08:34:57', '2026-03-14 08:34:57');

-- Table: plg_product_review_status
INSERT INTO plg_product_review_status (id, name, sort_no) VALUES (1, '公開', 1);
INSERT INTO plg_product_review_status (id, name, sort_no) VALUES (2, '非公開', 2);

-- Table: plg_recommend_product

-- Table: plg_related_product

-- Table: plg_site_kit_id_token

