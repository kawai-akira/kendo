-- DataMigrationBackup4 SQL Dump
-- Generated at: 2026-03-16 19:00:27

-- Table: doctrine_migration_versions

-- Table: dtb_authority_role

-- Table: dtb_base_info
INSERT INTO dtb_base_info (id, company_name, company_kana, postal_code, addr01, addr02, phone_number, business_hour, email01, email02, email03, email04, shop_name, shop_kana, shop_name_eng, update_date, good_traded, message, delivery_free_quantity, option_mypage_order_status_display, option_nostock_hidden, option_favorite_product, option_product_delivery_fee, option_product_tax_rule, option_customer_activate, option_remember_me, authentication_key, php_path, option_point, country_id, pref_id, discriminator_type, delivery_free_amount, basic_point_rate, point_conversion_rate) VALUES ('1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'smartitgroup.tech@gmail.com', 'smartitgroup.tech@gmail.com', 'smartitgroup.tech@gmail.com', 'smartitgroup.tech@gmail.com', 'DEMO', NULL, NULL, '2026-03-14 09:45:36', NULL, NULL, NULL, '1', '0', '1', '0', '0', '1', '1', NULL, NULL, '1', NULL, NULL, 'baseinfo', NULL, '1', '1');

-- Table: dtb_block
INSERT INTO dtb_block (id, block_name, file_name, use_controller, deletable, create_date, update_date, device_type_id, discriminator_type) VALUES ('1', 'カート', 'cart', '0', '0', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'block');
INSERT INTO dtb_block (id, block_name, file_name, use_controller, deletable, create_date, update_date, device_type_id, discriminator_type) VALUES ('2', 'カテゴリ', 'category', '0', '0', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'block');
INSERT INTO dtb_block (id, block_name, file_name, use_controller, deletable, create_date, update_date, device_type_id, discriminator_type) VALUES ('3', 'カテゴリナビ(PC)', 'category_nav_pc', '0', '0', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'block');
INSERT INTO dtb_block (id, block_name, file_name, use_controller, deletable, create_date, update_date, device_type_id, discriminator_type) VALUES ('4', 'カテゴリナビ(SP)', 'category_nav_sp', '0', '0', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'block');
INSERT INTO dtb_block (id, block_name, file_name, use_controller, deletable, create_date, update_date, device_type_id, discriminator_type) VALUES ('5', '新入荷商品特集', 'eyecatch', '0', '0', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'block');
INSERT INTO dtb_block (id, block_name, file_name, use_controller, deletable, create_date, update_date, device_type_id, discriminator_type) VALUES ('6', 'フッター', 'footer', '0', '0', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'block');
INSERT INTO dtb_block (id, block_name, file_name, use_controller, deletable, create_date, update_date, device_type_id, discriminator_type) VALUES ('7', 'ヘッダー(商品検索・ログインナビ・カート)', 'header', '0', '0', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'block');
INSERT INTO dtb_block (id, block_name, file_name, use_controller, deletable, create_date, update_date, device_type_id, discriminator_type) VALUES ('8', 'ログインナビ(共通)', 'login', '0', '0', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'block');
INSERT INTO dtb_block (id, block_name, file_name, use_controller, deletable, create_date, update_date, device_type_id, discriminator_type) VALUES ('9', 'ログインナビ(SP)', 'login_sp', '0', '0', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'block');
INSERT INTO dtb_block (id, block_name, file_name, use_controller, deletable, create_date, update_date, device_type_id, discriminator_type) VALUES ('10', 'ロゴ', 'logo', '0', '0', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'block');
INSERT INTO dtb_block (id, block_name, file_name, use_controller, deletable, create_date, update_date, device_type_id, discriminator_type) VALUES ('11', '新着商品', 'new_item', '0', '0', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'block');
INSERT INTO dtb_block (id, block_name, file_name, use_controller, deletable, create_date, update_date, device_type_id, discriminator_type) VALUES ('12', '新着情報', 'news', '0', '0', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'block');
INSERT INTO dtb_block (id, block_name, file_name, use_controller, deletable, create_date, update_date, device_type_id, discriminator_type) VALUES ('13', '商品検索', 'search_product', '1', '0', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'block');
INSERT INTO dtb_block (id, block_name, file_name, use_controller, deletable, create_date, update_date, device_type_id, discriminator_type) VALUES ('14', 'トピック', 'topic', '0', '0', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'block');

-- Table: dtb_block_position
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('3', '7', '1', '1', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('3', '10', '1', '2', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('3', '3', '1', '3', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('7', '5', '1', '1', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('7', '14', '1', '2', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('7', '11', '1', '3', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('7', '2', '1', '4', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('7', '12', '1', '5', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('10', '6', '1', '1', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('11', '13', '1', '1', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('11', '4', '1', '2', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('11', '9', '1', '3', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('3', '7', '2', '1', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('3', '10', '2', '2', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('3', '3', '2', '3', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('10', '6', '2', '1', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('11', '13', '2', '1', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('11', '4', '2', '2', 'blockposition');
INSERT INTO dtb_block_position (section, block_id, layout_id, block_row, discriminator_type) VALUES ('11', '9', '2', '3', 'blockposition');

-- Table: dtb_cart

-- Table: dtb_cart_item

-- Table: dtb_category
INSERT INTO dtb_category (id, category_name, hierarchy, sort_no, create_date, update_date, parent_category_id, creator_id, discriminator_type) VALUES ('1', 'ジェラート', '1', '5', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, 'category');
INSERT INTO dtb_category (id, category_name, hierarchy, sort_no, create_date, update_date, parent_category_id, creator_id, discriminator_type) VALUES ('2', '新入荷', '1', '6', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, 'category');
INSERT INTO dtb_category (id, category_name, hierarchy, sort_no, create_date, update_date, parent_category_id, creator_id, discriminator_type) VALUES ('3', '彩のデザート', '2', '3', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '1', NULL, 'category');
INSERT INTO dtb_category (id, category_name, hierarchy, sort_no, create_date, update_date, parent_category_id, creator_id, discriminator_type) VALUES ('4', 'CUBE', '3', '2', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '3', NULL, 'category');
INSERT INTO dtb_category (id, category_name, hierarchy, sort_no, create_date, update_date, parent_category_id, creator_id, discriminator_type) VALUES ('5', 'アイスサンド', '1', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, 'category');
INSERT INTO dtb_category (id, category_name, hierarchy, sort_no, create_date, update_date, parent_category_id, creator_id, discriminator_type) VALUES ('6', 'フルーツ', '2', '4', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '5', NULL, 'category');

-- Table: dtb_class_category
INSERT INTO dtb_class_category (id, backend_name, name, sort_no, visible, create_date, update_date, class_name_id, creator_id, discriminator_type) VALUES ('1', 'チョコ', 'チョコ', '3', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '1', NULL, 'classcategory');
INSERT INTO dtb_class_category (id, backend_name, name, sort_no, visible, create_date, update_date, class_name_id, creator_id, discriminator_type) VALUES ('2', '抹茶', '抹茶', '2', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '1', NULL, 'classcategory');
INSERT INTO dtb_class_category (id, backend_name, name, sort_no, visible, create_date, update_date, class_name_id, creator_id, discriminator_type) VALUES ('3', 'バニラ', 'バニラ', '1', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '1', NULL, 'classcategory');
INSERT INTO dtb_class_category (id, backend_name, name, sort_no, visible, create_date, update_date, class_name_id, creator_id, discriminator_type) VALUES ('4', '16mm × 16mm', '16mm × 16mm', '3', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '2', NULL, 'classcategory');
INSERT INTO dtb_class_category (id, backend_name, name, sort_no, visible, create_date, update_date, class_name_id, creator_id, discriminator_type) VALUES ('5', '32mm × 32mm', '32mm × 32mm', '2', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '2', NULL, 'classcategory');
INSERT INTO dtb_class_category (id, backend_name, name, sort_no, visible, create_date, update_date, class_name_id, creator_id, discriminator_type) VALUES ('6', '64cm × 64cm', '64cm × 64cm', '1', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '2', NULL, 'classcategory');

-- Table: dtb_class_name
INSERT INTO dtb_class_name (id, backend_name, name, sort_no, create_date, update_date, creator_id, discriminator_type) VALUES ('1', 'CUBE用味', 'フレーバー', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, 'classname');
INSERT INTO dtb_class_name (id, backend_name, name, sort_no, create_date, update_date, creator_id, discriminator_type) VALUES ('2', 'CUBE用サイズ', 'サイズ', '2', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, 'classname');

-- Table: dtb_csv
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('1', 'Eccube\\Entity\\Product', 'id', NULL, '商品ID', '1', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('2', 'Eccube\\Entity\\Product', 'Status', 'id', '公開ステータス(ID)', '2', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('3', 'Eccube\\Entity\\Product', 'Status', 'name', '公開ステータス(名称)', '3', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('4', 'Eccube\\Entity\\Product', 'name', NULL, '商品名', '4', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('5', 'Eccube\\Entity\\Product', 'note', NULL, 'ショップ用メモ欄', '5', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('6', 'Eccube\\Entity\\Product', 'description_list', NULL, '商品説明(一覧)', '6', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('7', 'Eccube\\Entity\\Product', 'description_detail', NULL, '商品説明(詳細)', '7', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('8', 'Eccube\\Entity\\Product', 'search_word', NULL, '検索ワード', '8', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('9', 'Eccube\\Entity\\Product', 'free_area', NULL, 'フリーエリア', '9', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('10', 'Eccube\\Entity\\ProductClass', 'id', NULL, '商品規格ID', '10', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('11', 'Eccube\\Entity\\ProductClass', 'SaleType', 'id', '販売種別(ID)', '11', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('12', 'Eccube\\Entity\\ProductClass', 'SaleType', 'name', '販売種別(名称)', '12', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('13', 'Eccube\\Entity\\ProductClass', 'ClassCategory1', 'id', '規格分類1(ID)', '13', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('14', 'Eccube\\Entity\\ProductClass', 'ClassCategory1', 'name', '規格分類1(名称)', '14', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('15', 'Eccube\\Entity\\ProductClass', 'ClassCategory2', 'id', '規格分類2(ID)', '15', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('16', 'Eccube\\Entity\\ProductClass', 'ClassCategory2', 'name', '規格分類2(名称)', '16', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('17', 'Eccube\\Entity\\ProductClass', 'DeliveryDuration', 'id', '発送日目安(ID)', '17', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('18', 'Eccube\\Entity\\ProductClass', 'DeliveryDuration', 'name', '発送日目安(名称)', '18', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('19', 'Eccube\\Entity\\ProductClass', 'code', NULL, '商品コード', '19', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('20', 'Eccube\\Entity\\ProductClass', 'stock', NULL, '在庫数', '20', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('21', 'Eccube\\Entity\\ProductClass', 'stock_unlimited', NULL, '在庫数無制限フラグ', '21', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('22', 'Eccube\\Entity\\ProductClass', 'sale_limit', NULL, '販売制限数', '22', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('23', 'Eccube\\Entity\\ProductClass', 'price01', NULL, '通常価格', '23', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('24', 'Eccube\\Entity\\ProductClass', 'price02', NULL, '販売価格', '24', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('25', 'Eccube\\Entity\\ProductClass', 'delivery_fee', NULL, '送料', '25', '0', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('26', 'Eccube\\Entity\\Product', 'ProductImage', 'file_name', '商品画像', '26', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('27', 'Eccube\\Entity\\Product', 'ProductCategories', 'category_id', '商品カテゴリ(ID)', '27', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('28', 'Eccube\\Entity\\Product', 'ProductCategories', 'Category', '商品カテゴリ(名称)', '28', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('29', 'Eccube\\Entity\\Product', 'ProductTag', 'tag_id', 'タグ(ID)', '29', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('30', 'Eccube\\Entity\\Product', 'ProductTag', 'Tag', 'タグ(名称)', '30', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('31', 'Eccube\\Entity\\Customer', 'id', NULL, '会員ID', '1', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('32', 'Eccube\\Entity\\Customer', 'name01', NULL, 'お名前(姓)', '2', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('33', 'Eccube\\Entity\\Customer', 'name02', NULL, 'お名前(名)', '3', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('34', 'Eccube\\Entity\\Customer', 'kana01', NULL, 'お名前(セイ)', '4', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('35', 'Eccube\\Entity\\Customer', 'kana02', NULL, 'お名前(メイ)', '5', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('36', 'Eccube\\Entity\\Customer', 'company_name', NULL, '会社名', '6', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('37', 'Eccube\\Entity\\Customer', 'postal_code', NULL, '郵便番号', '7', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('38', 'Eccube\\Entity\\Customer', 'Pref', 'id', '都道府県(ID)', '9', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('39', 'Eccube\\Entity\\Customer', 'Pref', 'name', '都道府県(名称)', '10', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('40', 'Eccube\\Entity\\Customer', 'addr01', NULL, '住所1', '11', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('41', 'Eccube\\Entity\\Customer', 'addr02', NULL, '住所2', '12', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('42', 'Eccube\\Entity\\Customer', 'email', NULL, 'メールアドレス', '13', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('43', 'Eccube\\Entity\\Customer', 'phone_number', NULL, 'TEL', '14', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('44', 'Eccube\\Entity\\Customer', 'Sex', 'id', '性別(ID)', '20', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('45', 'Eccube\\Entity\\Customer', 'Sex', 'name', '性別(名称)', '21', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('46', 'Eccube\\Entity\\Customer', 'Job', 'id', '職業(ID)', '22', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('47', 'Eccube\\Entity\\Customer', 'Job', 'name', '職業(名称)', '23', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('48', 'Eccube\\Entity\\Customer', 'birth', NULL, '誕生日', '24', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('49', 'Eccube\\Entity\\Customer', 'first_buy_date', NULL, '初回購入日', '25', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('50', 'Eccube\\Entity\\Customer', 'last_buy_date', NULL, '最終購入日', '26', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('51', 'Eccube\\Entity\\Customer', 'buy_times', NULL, '購入回数', '27', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('52', 'Eccube\\Entity\\Customer', 'note', NULL, 'ショップ用メモ欄', '28', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('53', 'Eccube\\Entity\\Customer', 'Status', 'id', '会員ステータス(ID)', '29', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('54', 'Eccube\\Entity\\Customer', 'Status', 'name', '会員ステータス(名称)', '30', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('55', 'Eccube\\Entity\\Customer', 'create_date', NULL, '登録日', '31', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('56', 'Eccube\\Entity\\Customer', 'update_date', NULL, '更新日', '32', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '2', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('57', 'Eccube\\Entity\\Order', 'id', NULL, '注文ID', '1', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('58', 'Eccube\\Entity\\Order', 'order_no', NULL, '注文番号', '2', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('59', 'Eccube\\Entity\\Order', 'Customer', 'id', '会員ID', '3', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('60', 'Eccube\\Entity\\Order', 'name01', NULL, 'お名前(姓)', '4', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('61', 'Eccube\\Entity\\Order', 'name02', NULL, 'お名前(名)', '5', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('62', 'Eccube\\Entity\\Order', 'kana01', NULL, 'お名前(セイ)', '6', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('63', 'Eccube\\Entity\\Order', 'kana02', NULL, 'お名前(メイ)', '7', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('64', 'Eccube\\Entity\\Order', 'company_name', NULL, '会社名', '8', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('65', 'Eccube\\Entity\\Order', 'postal_code', NULL, '郵便番号', '9', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('66', 'Eccube\\Entity\\Order', 'Pref', 'id', '都道府県(ID)', '10', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('67', 'Eccube\\Entity\\Order', 'Pref', 'name', '都道府県(名称)', '11', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('68', 'Eccube\\Entity\\Order', 'addr01', NULL, '住所1', '12', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('69', 'Eccube\\Entity\\Order', 'addr02', NULL, '住所2', '13', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('70', 'Eccube\\Entity\\Order', 'email', NULL, 'メールアドレス', '14', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('71', 'Eccube\\Entity\\Order', 'phone_number', NULL, 'TEL', '15', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('72', 'Eccube\\Entity\\Order', 'Sex', 'id', '性別(ID)', '16', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('73', 'Eccube\\Entity\\Order', 'Sex', 'name', '性別(名称)', '17', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('74', 'Eccube\\Entity\\Order', 'Job', 'id', '職業(ID)', '18', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('75', 'Eccube\\Entity\\Order', 'Job', 'name', '職業(名称)', '19', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('76', 'Eccube\\Entity\\Order', 'birth', NULL, '誕生日', '20', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('77', 'Eccube\\Entity\\Order', 'note', NULL, 'ショップ用メモ欄', '21', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('78', 'Eccube\\Entity\\Order', 'subtotal', NULL, '小計', '22', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('79', 'Eccube\\Entity\\Order', 'discount', NULL, '値引き', '23', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('80', 'Eccube\\Entity\\Order', 'delivery_fee_total', NULL, '送料', '24', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('81', 'Eccube\\Entity\\Order', 'tax', NULL, '税金', '25', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('82', 'Eccube\\Entity\\Order', 'total', NULL, '合計', '26', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('83', 'Eccube\\Entity\\Order', 'payment_total', NULL, '支払合計', '27', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('84', 'Eccube\\Entity\\Order', 'OrderStatus', 'id', '対応状況(ID)', '28', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('85', 'Eccube\\Entity\\Order', 'OrderStatus', 'name', '対応状況(名称)', '29', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('86', 'Eccube\\Entity\\Order', 'Payment', 'id', '支払方法(ID)', '30', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('87', 'Eccube\\Entity\\Order', 'payment_method', NULL, '支払方法(名称)', '31', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('88', 'Eccube\\Entity\\Order', 'order_date', NULL, '受注日', '32', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('89', 'Eccube\\Entity\\Order', 'payment_date', NULL, '入金日', '33', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('90', 'Eccube\\Entity\\OrderItem', 'id', NULL, '注文詳細ID', '34', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('91', 'Eccube\\Entity\\OrderItem', 'Product', 'id', '商品ID', '35', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('92', 'Eccube\\Entity\\OrderItem', 'ProductClass', 'id', '商品規格ID', '36', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('93', 'Eccube\\Entity\\OrderItem', 'product_name', NULL, '商品名', '37', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('94', 'Eccube\\Entity\\OrderItem', 'product_code', NULL, '商品コード', '38', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('95', 'Eccube\\Entity\\OrderItem', 'class_name1', NULL, '規格名1', '39', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('96', 'Eccube\\Entity\\OrderItem', 'class_name2', NULL, '規格名2', '40', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('97', 'Eccube\\Entity\\OrderItem', 'class_category_name1', NULL, '規格分類名1', '41', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('98', 'Eccube\\Entity\\OrderItem', 'class_category_name2', NULL, '規格分類名2', '42', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('99', 'Eccube\\Entity\\OrderItem', 'price', NULL, '価格', '43', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('100', 'Eccube\\Entity\\OrderItem', 'quantity', NULL, '個数', '44', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('101', 'Eccube\\Entity\\OrderItem', 'tax_rate', NULL, '税率', '45', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('102', 'Eccube\\Entity\\OrderItem', 'tax_rule', NULL, '税率ルール(ID)', '46', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('103', 'Eccube\\Entity\\OrderItem', 'OrderItemType', 'id', '明細区分(ID)', '47', '1', '2018-07-23 09:00:00', '2018-07-23 09:00:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('104', 'Eccube\\Entity\\OrderItem', 'OrderItemType', 'name', '明細区分(名称)', '48', '1', '2018-07-23 09:00:00', '2018-07-23 09:00:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('105', 'Eccube\\Entity\\Shipping', 'id', NULL, '出荷ID', '49', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('106', 'Eccube\\Entity\\Shipping', 'name01', NULL, '配送先_お名前(姓)', '50', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('107', 'Eccube\\Entity\\Shipping', 'name02', NULL, '配送先_お名前(名)', '51', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('108', 'Eccube\\Entity\\Shipping', 'kana01', NULL, '配送先_お名前(セイ)', '52', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('109', 'Eccube\\Entity\\Shipping', 'kana02', NULL, '配送先_お名前(メイ)', '53', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('110', 'Eccube\\Entity\\Shipping', 'company_name', NULL, '配送先_会社名', '54', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('111', 'Eccube\\Entity\\Shipping', 'postal_code', NULL, '配送先_郵便番号', '55', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('112', 'Eccube\\Entity\\Shipping', 'Pref', 'id', '配送先_都道府県(ID)', '56', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('113', 'Eccube\\Entity\\Shipping', 'Pref', 'name', '配送先_都道府県(名称)', '57', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('114', 'Eccube\\Entity\\Shipping', 'addr01', NULL, '配送先_住所1', '58', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('115', 'Eccube\\Entity\\Shipping', 'addr02', NULL, '配送先_住所2', '59', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('116', 'Eccube\\Entity\\Shipping', 'phone_number', NULL, '配送先_TEL', '60', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('117', 'Eccube\\Entity\\Shipping', 'Delivery', 'id', '配送業者(ID)', '61', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('118', 'Eccube\\Entity\\Shipping', 'shipping_delivery_name', NULL, '配送業者(名称)', '62', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('119', 'Eccube\\Entity\\Shipping', 'DeliveryTime', 'id', 'お届け時間ID', '63', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('120', 'Eccube\\Entity\\Shipping', 'shipping_delivery_time', NULL, 'お届け時間(名称)', '64', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('121', 'Eccube\\Entity\\Shipping', 'shipping_delivery_date', NULL, 'お届け希望日', '65', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('122', 'Eccube\\Entity\\Shipping', 'DeliveryFee', 'id', '送料ID', '66', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('123', 'Eccube\\Entity\\Shipping', 'shipping_delivery_fee', NULL, '送料', '67', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('124', 'Eccube\\Entity\\Shipping', 'shipping_date', NULL, '発送日', '68', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('125', 'Eccube\\Entity\\Shipping', 'tracking_number', NULL, '出荷伝票番号', '69', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('126', 'Eccube\\Entity\\Shipping', 'note', NULL, '配達用メモ', '70', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('127', 'Eccube\\Entity\\Shipping', 'mail_send_date', NULL, '出荷メール送信日', '71', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '3', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('128', 'Eccube\\Entity\\Order', 'id', NULL, '注文ID', '1', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('129', 'Eccube\\Entity\\Order', 'order_no', NULL, '注文番号', '2', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('130', 'Eccube\\Entity\\Order', 'Customer', 'id', '会員ID', '3', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('131', 'Eccube\\Entity\\Order', 'name01', NULL, 'お名前(姓)', '4', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('132', 'Eccube\\Entity\\Order', 'name02', NULL, 'お名前(名)', '5', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('133', 'Eccube\\Entity\\Order', 'kana01', NULL, 'お名前(セイ)', '6', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('134', 'Eccube\\Entity\\Order', 'kana02', NULL, 'お名前(メイ)', '7', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('135', 'Eccube\\Entity\\Order', 'company_name', NULL, '会社名', '8', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('136', 'Eccube\\Entity\\Order', 'postal_code', NULL, '郵便番号', '9', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('137', 'Eccube\\Entity\\Order', 'Pref', 'id', '都道府県(ID)', '10', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('138', 'Eccube\\Entity\\Order', 'Pref', 'name', '都道府県(名称)', '11', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('139', 'Eccube\\Entity\\Order', 'addr01', NULL, '住所1', '12', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('140', 'Eccube\\Entity\\Order', 'addr02', NULL, '住所2', '13', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('141', 'Eccube\\Entity\\Order', 'email', NULL, 'メールアドレス', '14', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('142', 'Eccube\\Entity\\Order', 'phone_number', NULL, 'TEL', '15', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('143', 'Eccube\\Entity\\Order', 'Sex', 'id', '性別(ID)', '16', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('144', 'Eccube\\Entity\\Order', 'Sex', 'name', '性別(名称)', '17', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('145', 'Eccube\\Entity\\Order', 'Job', 'id', '職業(ID)', '18', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('146', 'Eccube\\Entity\\Order', 'Job', 'name', '職業(名称)', '19', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('147', 'Eccube\\Entity\\Order', 'birth', NULL, '誕生日', '20', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('148', 'Eccube\\Entity\\Order', 'note', NULL, 'ショップ用メモ欄', '21', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('149', 'Eccube\\Entity\\Order', 'subtotal', NULL, '小計', '22', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('150', 'Eccube\\Entity\\Order', 'discount', NULL, '値引き', '23', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('151', 'Eccube\\Entity\\Order', 'delivery_fee_total', NULL, '送料', '24', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('152', 'Eccube\\Entity\\Order', 'tax', NULL, '税金', '25', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('153', 'Eccube\\Entity\\Order', 'total', NULL, '合計', '26', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('154', 'Eccube\\Entity\\Order', 'payment_total', NULL, '支払合計', '27', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('155', 'Eccube\\Entity\\Order', 'OrderStatus', 'id', '対応状況(ID)', '28', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('156', 'Eccube\\Entity\\Order', 'OrderStatus', 'name', '対応状況(名称)', '29', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('157', 'Eccube\\Entity\\Order', 'Payment', 'id', '支払方法(ID)', '30', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('158', 'Eccube\\Entity\\Order', 'payment_method', NULL, '支払方法(名称)', '31', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('159', 'Eccube\\Entity\\Order', 'order_date', NULL, '受注日', '32', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('160', 'Eccube\\Entity\\Order', 'payment_date', NULL, '入金日', '33', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('161', 'Eccube\\Entity\\OrderItem', 'id', NULL, '注文詳細ID', '34', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('162', 'Eccube\\Entity\\OrderItem', 'Product', 'id', '商品ID', '35', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('163', 'Eccube\\Entity\\OrderItem', 'ProductClass', 'id', '商品規格ID', '36', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('164', 'Eccube\\Entity\\OrderItem', 'product_name', NULL, '商品名', '37', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('165', 'Eccube\\Entity\\OrderItem', 'product_code', NULL, '商品コード', '38', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('166', 'Eccube\\Entity\\OrderItem', 'class_name1', NULL, '規格名1', '39', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('167', 'Eccube\\Entity\\OrderItem', 'class_name2', NULL, '規格名2', '40', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('168', 'Eccube\\Entity\\OrderItem', 'class_category_name1', NULL, '規格分類名1', '41', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('169', 'Eccube\\Entity\\OrderItem', 'class_category_name2', NULL, '規格分類名2', '42', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('170', 'Eccube\\Entity\\OrderItem', 'price', NULL, '価格', '43', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('171', 'Eccube\\Entity\\OrderItem', 'quantity', NULL, '個数', '44', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('172', 'Eccube\\Entity\\OrderItem', 'tax_rate', NULL, '税率', '45', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('173', 'Eccube\\Entity\\OrderItem', 'tax_rule', NULL, '税率ルール(ID)', '46', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('174', 'Eccube\\Entity\\OrderItem', 'OrderItemType', 'id', '明細区分(ID)', '47', '1', '2018-07-23 09:00:00', '2018-07-23 09:00:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('175', 'Eccube\\Entity\\OrderItem', 'OrderItemType', 'name', '明細区分(名称)', '48', '1', '2018-07-23 09:00:00', '2018-07-23 09:00:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('176', 'Eccube\\Entity\\Shipping', 'id', NULL, '出荷ID', '49', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('177', 'Eccube\\Entity\\Shipping', 'name01', NULL, '配送先_お名前(姓)', '50', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('178', 'Eccube\\Entity\\Shipping', 'name02', NULL, '配送先_お名前(名)', '51', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('179', 'Eccube\\Entity\\Shipping', 'kana01', NULL, '配送先_お名前(セイ)', '52', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('180', 'Eccube\\Entity\\Shipping', 'kana02', NULL, '配送先_お名前(メイ)', '53', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('181', 'Eccube\\Entity\\Shipping', 'company_name', NULL, '配送先_会社名', '54', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('182', 'Eccube\\Entity\\Shipping', 'postal_code', NULL, '配送先_郵便番号', '55', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('183', 'Eccube\\Entity\\Shipping', 'Pref', 'id', '配送先_都道府県(ID)', '56', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('184', 'Eccube\\Entity\\Shipping', 'Pref', 'name', '配送先_都道府県(名称)', '57', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('185', 'Eccube\\Entity\\Shipping', 'addr01', NULL, '配送先_住所1', '58', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('186', 'Eccube\\Entity\\Shipping', 'addr02', NULL, '配送先_住所2', '59', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('187', 'Eccube\\Entity\\Shipping', 'phone_number', NULL, '配送先_TEL', '60', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('188', 'Eccube\\Entity\\Shipping', 'Delivery', 'id', '配送業者(ID)', '61', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('189', 'Eccube\\Entity\\Shipping', 'shipping_delivery_name', NULL, '配送業者(名称)', '62', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('190', 'Eccube\\Entity\\Shipping', 'DeliveryTime', 'id', 'お届け時間ID', '63', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('191', 'Eccube\\Entity\\Shipping', 'shipping_delivery_time', NULL, 'お届け時間(名称)', '64', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('192', 'Eccube\\Entity\\Shipping', 'shipping_delivery_date', NULL, 'お届け希望日', '65', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('193', 'Eccube\\Entity\\Shipping', 'DeliveryFee', 'id', '送料ID', '66', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('194', 'Eccube\\Entity\\Shipping', 'shipping_delivery_fee', NULL, '送料', '67', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('195', 'Eccube\\Entity\\Shipping', 'shipping_date', NULL, '発送日', '68', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('196', 'Eccube\\Entity\\Shipping', 'tracking_number', NULL, '出荷伝票番号', '69', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('197', 'Eccube\\Entity\\Shipping', 'note', NULL, '配達用メモ', '70', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('198', 'Eccube\\Entity\\Shipping', 'mail_send_date', NULL, '出荷メール送信日', '71', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '4', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('199', 'Eccube\\Entity\\Category', 'id', NULL, 'カテゴリID', '1', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '5', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('200', 'Eccube\\Entity\\Category', 'sort_no', NULL, '表示ランク', '2', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '5', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('201', 'Eccube\\Entity\\Category', 'name', NULL, 'カテゴリ名', '3', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '5', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('202', 'Eccube\\Entity\\Category', 'Parent', 'id', '親カテゴリID', '4', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '5', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('203', 'Eccube\\Entity\\Category', 'level', NULL, '階層', '5', '1', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '5', NULL, 'csv');
INSERT INTO dtb_csv (id, entity_name, field_name, reference_field_name, disp_name, sort_no, enabled, create_date, update_date, csv_type_id, creator_id, discriminator_type) VALUES ('204', 'Eccube\\Entity\\ProductClass', 'TaxRule', 'tax_rate', '税率', '31', '0', '2017-03-07 10:14:00', '2017-03-07 10:14:00', '1', NULL, 'csv');

-- Table: dtb_customer

-- Table: dtb_customer_address

-- Table: dtb_customer_favorite_product

-- Table: dtb_delivery
INSERT INTO dtb_delivery (id, name, service_name, description, confirm_url, sort_no, visible, create_date, update_date, creator_id, sale_type_id, discriminator_type) VALUES ('1', 'サンプル業者', 'サンプル業者', NULL, NULL, '1', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, '1', 'delivery');
INSERT INTO dtb_delivery (id, name, service_name, description, confirm_url, sort_no, visible, create_date, update_date, creator_id, sale_type_id, discriminator_type) VALUES ('2', 'サンプル宅配', 'サンプル宅配', NULL, NULL, '2', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, '2', 'delivery');

-- Table: dtb_delivery_duration
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES ('1', '即日', '0', '0', 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES ('2', '1～2日後', '1', '1', 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES ('3', '3～4日後', '3', '2', 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES ('4', '1週間以降', '7', '3', 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES ('5', '2週間以降', '14', '4', 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES ('6', '3週間以降', '21', '5', 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES ('7', '1ヶ月以降', '30', '6', 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES ('8', '2ヶ月以降', '60', '7', 'deliveryduration');
INSERT INTO dtb_delivery_duration (id, name, duration, sort_no, discriminator_type) VALUES ('9', 'お取り寄せ(商品入荷後)', '-1', '8', 'deliveryduration');

-- Table: dtb_delivery_fee
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('1', '1', '1', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('2', '1', '2', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('3', '1', '3', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('4', '1', '4', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('5', '1', '5', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('6', '1', '6', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('7', '1', '7', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('8', '1', '8', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('9', '1', '9', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('10', '1', '10', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('11', '1', '11', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('12', '1', '12', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('13', '1', '13', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('14', '1', '14', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('15', '1', '15', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('16', '1', '16', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('17', '1', '17', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('18', '1', '18', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('19', '1', '19', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('20', '1', '20', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('21', '1', '21', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('22', '1', '22', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('23', '1', '23', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('24', '1', '24', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('25', '1', '25', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('26', '1', '26', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('27', '1', '27', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('28', '1', '28', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('29', '1', '29', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('30', '1', '30', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('31', '1', '31', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('32', '1', '32', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('33', '1', '33', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('34', '1', '34', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('35', '1', '35', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('36', '1', '36', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('37', '1', '37', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('38', '1', '38', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('39', '1', '39', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('40', '1', '40', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('41', '1', '41', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('42', '1', '42', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('43', '1', '43', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('44', '1', '44', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('45', '1', '45', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('46', '1', '46', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('47', '1', '47', 'deliveryfee', '1000');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('48', '2', '1', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('49', '2', '2', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('50', '2', '3', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('51', '2', '4', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('52', '2', '5', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('53', '2', '6', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('54', '2', '7', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('55', '2', '8', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('56', '2', '9', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('57', '2', '10', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('58', '2', '11', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('59', '2', '12', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('60', '2', '13', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('61', '2', '14', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('62', '2', '15', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('63', '2', '16', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('64', '2', '17', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('65', '2', '18', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('66', '2', '19', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('67', '2', '20', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('68', '2', '21', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('69', '2', '22', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('70', '2', '23', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('71', '2', '24', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('72', '2', '25', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('73', '2', '26', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('74', '2', '27', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('75', '2', '28', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('76', '2', '29', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('77', '2', '30', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('78', '2', '31', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('79', '2', '32', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('80', '2', '33', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('81', '2', '34', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('82', '2', '35', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('83', '2', '36', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('84', '2', '37', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('85', '2', '38', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('86', '2', '39', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('87', '2', '40', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('88', '2', '41', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('89', '2', '42', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('90', '2', '43', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('91', '2', '44', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('92', '2', '45', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('93', '2', '46', 'deliveryfee', '0');
INSERT INTO dtb_delivery_fee (id, delivery_id, pref_id, discriminator_type, fee) VALUES ('94', '2', '47', 'deliveryfee', '0');

-- Table: dtb_delivery_time
INSERT INTO dtb_delivery_time (id, delivery_time, sort_no, visible, create_date, update_date, delivery_id, discriminator_type) VALUES ('1', '午前', '1', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '1', 'deliverytime');
INSERT INTO dtb_delivery_time (id, delivery_time, sort_no, visible, create_date, update_date, delivery_id, discriminator_type) VALUES ('2', '午後', '2', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '1', 'deliverytime');

-- Table: dtb_layout
INSERT INTO dtb_layout (id, layout_name, create_date, update_date, device_type_id, discriminator_type) VALUES ('0', 'プレビュー用レイアウト', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'layout');
INSERT INTO dtb_layout (id, layout_name, create_date, update_date, device_type_id, discriminator_type) VALUES ('1', 'トップページ用レイアウト', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'layout');
INSERT INTO dtb_layout (id, layout_name, create_date, update_date, device_type_id, discriminator_type) VALUES ('2', '下層ページ用レイアウト', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'layout');

-- Table: dtb_mail_history

-- Table: dtb_mail_template
INSERT INTO dtb_mail_template (id, name, file_name, mail_subject, create_date, update_date, creator_id, discriminator_type) VALUES ('1', '注文受付メール', 'Mail/order.twig', 'ご注文ありがとうございます', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, 'mailtemplate');
INSERT INTO dtb_mail_template (id, name, file_name, mail_subject, create_date, update_date, creator_id, discriminator_type) VALUES ('2', '会員仮登録メール', 'Mail/entry_confirm.twig', '会員登録のご確認', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, 'mailtemplate');
INSERT INTO dtb_mail_template (id, name, file_name, mail_subject, create_date, update_date, creator_id, discriminator_type) VALUES ('3', '会員本登録メール', 'Mail/entry_complete.twig', '会員登録が完了しました。', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, 'mailtemplate');
INSERT INTO dtb_mail_template (id, name, file_name, mail_subject, create_date, update_date, creator_id, discriminator_type) VALUES ('4', '会員退会メール', 'Mail/customer_withdraw_mail.twig', '退会手続きのご完了', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, 'mailtemplate');
INSERT INTO dtb_mail_template (id, name, file_name, mail_subject, create_date, update_date, creator_id, discriminator_type) VALUES ('5', '問合受付メール', 'Mail/contact_mail.twig', 'お問い合わせを受け付けました。', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, 'mailtemplate');
INSERT INTO dtb_mail_template (id, name, file_name, mail_subject, create_date, update_date, creator_id, discriminator_type) VALUES ('6', 'パスワードリセット', 'Mail/forgot_mail.twig', 'パスワード変更のご確認', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, 'mailtemplate');
INSERT INTO dtb_mail_template (id, name, file_name, mail_subject, create_date, update_date, creator_id, discriminator_type) VALUES ('7', 'パスワードリマインダー', 'Mail/reset_complete_mail.twig', 'パスワード変更のお知らせ', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, 'mailtemplate');
INSERT INTO dtb_mail_template (id, name, file_name, mail_subject, create_date, update_date, creator_id, discriminator_type) VALUES ('8', '出荷通知メール', 'Mail/shipping_notify.twig', '商品出荷のお知らせ', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, 'mailtemplate');

-- Table: dtb_member
INSERT INTO dtb_member (id, name, department, login_id, password, salt, sort_no, create_date, update_date, login_date, work_id, authority_id, creator_id, discriminator_type) VALUES ('1', '管理者', 'DEMO', 'admin', '7da2426f4764ddd6024c9752a9b710d0ed7e801845ad5f529339089643c86b2d', 'EYtBCaLpQafEFDHrARyjrKP1W1iVPsoG', '1', '2026-03-14 09:45:36', '2026-03-16 08:44:36', '2026-03-16 08:44:36', '1', '0', '1', 'member');

-- Table: dtb_news
INSERT INTO dtb_news (id, publish_date, title, description, url, link_method, create_date, update_date, visible, creator_id, discriminator_type) VALUES ('1', '2018-09-01 09:00:00', 'サイトオープンいたしました!', '旬の色どりスイーツとこだわりのジェラートをお届けします。', NULL, '1', '2018-09-01 09:00:00', '2018-09-01 09:00:00', '1', NULL, 'news');

-- Table: dtb_order

-- Table: dtb_order_item

-- Table: dtb_order_pdf

-- Table: dtb_page
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('0', 'プレビューデータ', 'preview', NULL, '1', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('1', 'TOPページ', 'homepage', 'index', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('2', '商品一覧ページ', 'product_list', 'Product/list', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('3', '商品詳細ページ', 'product_detail', 'Product/detail', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, '<meta property="og:type" content="og:product" /><meta property="og:title" content="{{ Product.name }}" />
<meta property="og:image" content="{{ url(''homepage'') }}{{ asset(Product.main_list_image|no_image_product, ''save_image'') }}" />
<meta property="og:description" content="{{ Product.description_list|striptags }}" />
<meta property="og:url" content="{{ url(''product_detail'', {''id'': Product.id}) }}" />
<meta property="product:price:amount" content="{{ Product.getPrice02IncTaxMin }}"/>
<meta property="product:price:currency" content="{{ eccube_config.currency }}"/>
<meta property="product:product_link" content="{{ url(''product_detail'', {''id'': Product.id}) }}"/>
<meta property="product:retailer_title" content="{{ BaseInfo.shop_name }}"/>', NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('4', 'MYページ', 'mypage', 'Mypage/index', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('5', 'MYページ/会員登録内容変更(入力ページ)', 'mypage_change', 'Mypage/change', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('6', 'MYページ/会員登録内容変更(完了ページ)', 'mypage_change_complete', 'Mypage/change_complete', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('7', 'MYページ/お届け先一覧', 'mypage_delivery', 'Mypage/delivery', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('8', 'MYページ/お届け先追加', 'mypage_delivery_new', 'Mypage/delivery_edit', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('9', 'MYページ/お気に入り一覧', 'mypage_favorite', 'Mypage/favorite', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('10', 'MYページ/購入履歴詳細', 'mypage_history', 'Mypage/history', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('11', 'MYページ/ログイン', 'mypage_login', 'Mypage/login', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('12', 'MYページ/退会手続き(入力ページ)', 'mypage_withdraw', 'Mypage/withdraw', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('13', 'MYページ/退会手続き(完了ページ)', 'mypage_withdraw_complete', 'Mypage/withdraw_complete', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('14', '当サイトについて', 'help_about', 'Help/about', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('15', '現在のカゴの中', 'cart', 'Cart/index', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('16', 'お問い合わせ(入力ページ)', 'contact', 'Contact/index', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('17', 'お問い合わせ(完了ページ)', 'contact_complete', 'Contact/complete', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('18', '会員登録(入力ページ)', 'entry', 'Entry/index', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('19', 'ご利用規約', 'help_agreement', 'Help/agreement', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('20', '会員登録(完了ページ)', 'entry_complete', 'Entry/complete', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('21', '特定商取引に関する法律に基づく表記', 'help_tradelaw', 'Help/tradelaw', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('22', '本会員登録(完了ページ)', 'entry_activate', 'Entry/activate', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('23', '商品購入', 'shopping', 'Shopping/index', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('24', '商品購入/お届け先の指定', 'shopping_shipping', 'Shopping/shipping', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('25', '商品購入/お届け先の複数指定', 'shopping_shipping_multiple', 'Shopping/shipping_multiple', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('28', '商品購入/ご注文完了', 'shopping_complete', 'Shopping/complete', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('29', 'プライバシーポリシー', 'help_privacy', 'Help/privacy', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('30', '商品購入ログイン', 'shopping_login', 'Shopping/login', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('31', '非会員購入情報入力', 'shopping_nonmember', 'Shopping/nonmember', '2', NULL, NULL, NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('32', '商品購入/お届け先の追加', 'shopping_shipping_edit', 'Shopping/shipping_edit', '2', NULL, NULL, NULL, '2017-03-07 01:15:02', '2017-03-07 01:15:02', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('33', '商品購入/お届け先の複数指定(お届け先の追加)', 'shopping_shipping_multiple_edit', 'Shopping/shipping_multiple_edit', '2', NULL, NULL, NULL, '2017-03-07 01:15:02', '2017-03-07 01:15:02', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('34', '商品購入/購入エラー', 'shopping_error', 'Shopping/shopping_error', '2', NULL, NULL, NULL, '2017-03-07 01:15:02', '2017-03-07 01:15:02', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('35', 'ご利用ガイド', 'help_guide', 'Help/guide', '2', NULL, NULL, NULL, '2017-03-07 01:15:02', '2017-03-07 01:15:02', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('36', 'パスワード再発行(入力ページ)', 'forgot', 'Forgot/index', '2', NULL, NULL, NULL, '2017-03-07 01:15:02', '2017-03-07 01:15:02', NULL, NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('37', 'パスワード再発行(完了ページ)', 'forgot_complete', 'Forgot/complete', '2', NULL, NULL, NULL, '2017-03-07 01:15:02', '2017-03-07 01:15:02', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('38', 'パスワード再発行(再設定ページ)', 'forgot_reset', 'Forgot/reset', '2', NULL, NULL, NULL, '2017-03-07 01:15:02', '2017-03-07 01:15:05', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('42', '商品購入/遷移', 'shopping_redirect_to', 'Shopping/index', '2', NULL, NULL, NULL, '2017-03-07 01:15:03', '2017-03-07 01:15:03', 'noindex', NULL, NULL, 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('44', 'MYページ/お届け先編集', 'mypage_delivery_edit', 'Mypage/delivery_edit', '2', NULL, NULL, NULL, '2017-03-07 01:15:05', '2017-03-07 01:15:05', 'noindex', NULL, '8', 'page');
INSERT INTO dtb_page (id, page_name, url, file_name, edit_type, author, description, keyword, create_date, update_date, meta_robots, meta_tags, master_page_id, discriminator_type) VALUES ('45', '商品購入/ご注文確認', 'shopping_confirm', 'Shopping/confirm', '2', NULL, NULL, NULL, '2017-03-07 01:15:03', '2017-03-07 01:15:03', 'noindex', NULL, NULL, 'page');

-- Table: dtb_page_layout
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('0', '0', '2', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('1', '1', '2', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('2', '2', '4', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('3', '2', '5', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('4', '2', '6', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('5', '2', '7', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('6', '2', '8', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('9', '2', '9', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('10', '2', '10', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('11', '2', '11', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('12', '2', '12', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('14', '2', '13', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('13', '2', '14', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('15', '2', '15', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('16', '2', '16', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('17', '2', '17', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('18', '2', '18', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('20', '2', '19', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('21', '2', '20', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('22', '2', '21', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('24', '2', '22', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('28', '2', '23', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('29', '2', '24', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('30', '2', '25', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('31', '2', '26', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('32', '2', '27', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('33', '2', '28', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('34', '2', '29', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('35', '2', '30', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('36', '2', '31', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('37', '2', '32', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('19', '2', '33', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('25', '2', '34', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('23', '2', '35', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('7', '2', '36', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('8', '2', '37', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('42', '2', '38', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('38', '2', '39', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('44', '2', '40', 'pagelayout');
INSERT INTO dtb_page_layout (page_id, layout_id, sort_no, discriminator_type) VALUES ('45', '2', '41', 'pagelayout');

-- Table: dtb_payment
INSERT INTO dtb_payment (id, payment_method, sort_no, fixed, payment_image, method_class, visible, create_date, update_date, creator_id, discriminator_type, charge, rule_max, rule_min) VALUES ('1', '郵便振替', '4', '1', NULL, 'Eccube\Service\Payment\Method\Cash', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, 'payment', '0', NULL, '0');
INSERT INTO dtb_payment (id, payment_method, sort_no, fixed, payment_image, method_class, visible, create_date, update_date, creator_id, discriminator_type, charge, rule_max, rule_min) VALUES ('2', '現金書留', '3', '1', NULL, 'Eccube\Service\Payment\Method\Cash', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, 'payment', '0', NULL, '0');
INSERT INTO dtb_payment (id, payment_method, sort_no, fixed, payment_image, method_class, visible, create_date, update_date, creator_id, discriminator_type, charge, rule_max, rule_min) VALUES ('3', '銀行振込', '2', '1', NULL, 'Eccube\Service\Payment\Method\Cash', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, 'payment', '0', NULL, '0');
INSERT INTO dtb_payment (id, payment_method, sort_no, fixed, payment_image, method_class, visible, create_date, update_date, creator_id, discriminator_type, charge, rule_max, rule_min) VALUES ('4', '代金引換', '1', '1', NULL, 'Eccube\Service\Payment\Method\Cash', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, 'payment', '0', NULL, '0');

-- Table: dtb_payment_option
INSERT INTO dtb_payment_option (delivery_id, payment_id, discriminator_type) VALUES ('1', '1', 'paymentoption');
INSERT INTO dtb_payment_option (delivery_id, payment_id, discriminator_type) VALUES ('1', '2', 'paymentoption');
INSERT INTO dtb_payment_option (delivery_id, payment_id, discriminator_type) VALUES ('1', '3', 'paymentoption');
INSERT INTO dtb_payment_option (delivery_id, payment_id, discriminator_type) VALUES ('1', '4', 'paymentoption');
INSERT INTO dtb_payment_option (delivery_id, payment_id, discriminator_type) VALUES ('2', '3', 'paymentoption');

-- Table: dtb_plugin
INSERT INTO dtb_plugin (id, name, code, enabled, version, source, initialized, create_date, update_date, discriminator_type) VALUES ('1', 'データ移行向けバックアップ生成プラグイン for EC-CUBE 4', 'DataMigrationBackup42', '1', '1.0.10', '0', '1', '2026-03-16 07:04:58', '2026-03-16 07:06:29', 'plugin');

-- Table: dtb_product
INSERT INTO dtb_product (id, name, note, description_list, description_detail, search_word, free_area, create_date, update_date, creator_id, product_status_id, discriminator_type) VALUES ('1', '彩のジェラートCUBE', NULL, NULL, '冬でも食べたい立方体のジェラート。定番のチョコフレーバーは、チョコレート特有の甘い香りが特徴です。適度な甘みと日本人の口に合いやすいサイズ感で長く愛用いただけます。
最高級バニラフレーバーは、贈り物としても人気です。', NULL, NULL, '2018-09-28 10:14:52', '2018-09-28 10:14:52', NULL, '1', 'product');
INSERT INTO dtb_product (id, name, note, description_list, description_detail, search_word, free_area, create_date, update_date, creator_id, product_status_id, discriminator_type) VALUES ('2', 'チェリーアイスサンド', NULL, NULL, 'チェリーアイスサンドは北海道産のチェリーのアイスをサクサクのクッキーでサンドしたスイーツです。立方体なので大量に持ち運ぶときも便利です。
いまだけ、頑丈な箱つきです。', NULL, NULL, '2018-09-28 10:14:52', '2018-09-28 10:14:52', NULL, '1', 'product');

-- Table: dtb_product_category
INSERT INTO dtb_product_category (product_id, category_id, discriminator_type) VALUES ('1', '1', 'productcategory');
INSERT INTO dtb_product_category (product_id, category_id, discriminator_type) VALUES ('1', '2', 'productcategory');
INSERT INTO dtb_product_category (product_id, category_id, discriminator_type) VALUES ('1', '3', 'productcategory');
INSERT INTO dtb_product_category (product_id, category_id, discriminator_type) VALUES ('1', '4', 'productcategory');
INSERT INTO dtb_product_category (product_id, category_id, discriminator_type) VALUES ('2', '2', 'productcategory');
INSERT INTO dtb_product_category (product_id, category_id, discriminator_type) VALUES ('2', '5', 'productcategory');
INSERT INTO dtb_product_category (product_id, category_id, discriminator_type) VALUES ('2', '6', 'productcategory');

-- Table: dtb_product_class
INSERT INTO dtb_product_class (id, product_code, stock, stock_unlimited, price01, price02, visible, create_date, update_date, currency_code, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, discriminator_type, sale_limit, delivery_fee, point_rate) VALUES ('1', NULL, NULL, '1', '115000', '110000', '0', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', '1', '1', NULL, NULL, NULL, NULL, 'productclass', NULL, NULL, NULL);
INSERT INTO dtb_product_class (id, product_code, stock, stock_unlimited, price01, price02, visible, create_date, update_date, currency_code, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, discriminator_type, sale_limit, delivery_fee, point_rate) VALUES ('2', 'cube-01', NULL, '1', '115000', '110000', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', '1', '1', '3', '6', NULL, NULL, 'productclass', NULL, NULL, NULL);
INSERT INTO dtb_product_class (id, product_code, stock, stock_unlimited, price01, price02, visible, create_date, update_date, currency_code, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, discriminator_type, sale_limit, delivery_fee, point_rate) VALUES ('3', 'cube-02', NULL, '1', '95000', '93000', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', '1', '1', '3', '5', NULL, NULL, 'productclass', NULL, NULL, NULL);
INSERT INTO dtb_product_class (id, product_code, stock, stock_unlimited, price01, price02, visible, create_date, update_date, currency_code, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, discriminator_type, sale_limit, delivery_fee, point_rate) VALUES ('4', 'cube-03', NULL, '1', '75000', '74000', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', '1', '1', '3', '4', NULL, NULL, 'productclass', NULL, NULL, NULL);
INSERT INTO dtb_product_class (id, product_code, stock, stock_unlimited, price01, price02, visible, create_date, update_date, currency_code, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, discriminator_type, sale_limit, delivery_fee, point_rate) VALUES ('5', 'cube-04', NULL, '1', '95000', '93000', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', '1', '1', '2', '6', NULL, NULL, 'productclass', NULL, NULL, NULL);
INSERT INTO dtb_product_class (id, product_code, stock, stock_unlimited, price01, price02, visible, create_date, update_date, currency_code, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, discriminator_type, sale_limit, delivery_fee, point_rate) VALUES ('6', 'cube-05', NULL, '1', '50000', '49000', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', '1', '1', '2', '5', NULL, NULL, 'productclass', NULL, NULL, NULL);
INSERT INTO dtb_product_class (id, product_code, stock, stock_unlimited, price01, price02, visible, create_date, update_date, currency_code, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, discriminator_type, sale_limit, delivery_fee, point_rate) VALUES ('7', 'cube-06', NULL, '1', '35000', '34500', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', '1', '1', '2', '4', NULL, NULL, 'productclass', NULL, NULL, NULL);
INSERT INTO dtb_product_class (id, product_code, stock, stock_unlimited, price01, price02, visible, create_date, update_date, currency_code, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, discriminator_type, sale_limit, delivery_fee, point_rate) VALUES ('8', 'cube-07', NULL, '1', NULL, '18000', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', '1', '1', '1', '6', NULL, NULL, 'productclass', NULL, NULL, NULL);
INSERT INTO dtb_product_class (id, product_code, stock, stock_unlimited, price01, price02, visible, create_date, update_date, currency_code, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, discriminator_type, sale_limit, delivery_fee, point_rate) VALUES ('9', 'cube-08', NULL, '1', NULL, '13000', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', '1', '1', '1', '5', NULL, NULL, 'productclass', NULL, NULL, NULL);
INSERT INTO dtb_product_class (id, product_code, stock, stock_unlimited, price01, price02, visible, create_date, update_date, currency_code, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, discriminator_type, sale_limit, delivery_fee, point_rate) VALUES ('10', 'cube-09', NULL, '1', NULL, '5000', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', '1', '1', '1', '4', NULL, NULL, 'productclass', NULL, NULL, NULL);
INSERT INTO dtb_product_class (id, product_code, stock, stock_unlimited, price01, price02, visible, create_date, update_date, currency_code, product_id, sale_type_id, class_category_id1, class_category_id2, delivery_duration_id, creator_id, discriminator_type, sale_limit, delivery_fee, point_rate) VALUES ('11', 'sand-01', '100', '0', '3000', '2800', '1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', 'JPY', '2', '1', NULL, NULL, NULL, NULL, 'productclass', '5', NULL, NULL);

-- Table: dtb_product_image
INSERT INTO dtb_product_image (id, file_name, sort_no, create_date, product_id, creator_id, discriminator_type) VALUES ('1', 'cube-1.png', '1', '2017-03-07 10:14:52', '1', NULL, 'productimage');
INSERT INTO dtb_product_image (id, file_name, sort_no, create_date, product_id, creator_id, discriminator_type) VALUES ('2', 'cube-2.png', '2', '2017-03-07 10:14:52', '1', NULL, 'productimage');
INSERT INTO dtb_product_image (id, file_name, sort_no, create_date, product_id, creator_id, discriminator_type) VALUES ('3', 'cube-3.png', '3', '2017-03-07 10:14:52', '1', NULL, 'productimage');
INSERT INTO dtb_product_image (id, file_name, sort_no, create_date, product_id, creator_id, discriminator_type) VALUES ('4', 'sand-1.png', '1', '2017-03-07 10:14:52', '2', NULL, 'productimage');
INSERT INTO dtb_product_image (id, file_name, sort_no, create_date, product_id, creator_id, discriminator_type) VALUES ('5', 'sand-2.png', '2', '2017-03-07 10:14:52', '2', NULL, 'productimage');
INSERT INTO dtb_product_image (id, file_name, sort_no, create_date, product_id, creator_id, discriminator_type) VALUES ('6', 'sand-3.png', '3', '2017-03-07 10:14:52', '2', NULL, 'productimage');

-- Table: dtb_product_stock
INSERT INTO dtb_product_stock (id, stock, create_date, update_date, product_class_id, creator_id, discriminator_type) VALUES ('1', NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', '1', NULL, 'productstock');
INSERT INTO dtb_product_stock (id, stock, create_date, update_date, product_class_id, creator_id, discriminator_type) VALUES ('2', NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', '2', NULL, 'productstock');
INSERT INTO dtb_product_stock (id, stock, create_date, update_date, product_class_id, creator_id, discriminator_type) VALUES ('3', NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', '3', NULL, 'productstock');
INSERT INTO dtb_product_stock (id, stock, create_date, update_date, product_class_id, creator_id, discriminator_type) VALUES ('4', NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', '4', NULL, 'productstock');
INSERT INTO dtb_product_stock (id, stock, create_date, update_date, product_class_id, creator_id, discriminator_type) VALUES ('5', NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', '5', NULL, 'productstock');
INSERT INTO dtb_product_stock (id, stock, create_date, update_date, product_class_id, creator_id, discriminator_type) VALUES ('6', NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', '6', NULL, 'productstock');
INSERT INTO dtb_product_stock (id, stock, create_date, update_date, product_class_id, creator_id, discriminator_type) VALUES ('7', NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', '7', NULL, 'productstock');
INSERT INTO dtb_product_stock (id, stock, create_date, update_date, product_class_id, creator_id, discriminator_type) VALUES ('8', NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', '8', NULL, 'productstock');
INSERT INTO dtb_product_stock (id, stock, create_date, update_date, product_class_id, creator_id, discriminator_type) VALUES ('9', NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', '9', NULL, 'productstock');
INSERT INTO dtb_product_stock (id, stock, create_date, update_date, product_class_id, creator_id, discriminator_type) VALUES ('10', NULL, '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', NULL, 'productstock');
INSERT INTO dtb_product_stock (id, stock, create_date, update_date, product_class_id, creator_id, discriminator_type) VALUES ('11', '100', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '11', NULL, 'productstock');

-- Table: dtb_product_tag

-- Table: dtb_shipping

-- Table: dtb_tag
INSERT INTO dtb_tag (id, name, sort_no, discriminator_type) VALUES ('1', '新商品', '1', 'tag');
INSERT INTO dtb_tag (id, name, sort_no, discriminator_type) VALUES ('2', 'おすすめ商品', '2', 'tag');
INSERT INTO dtb_tag (id, name, sort_no, discriminator_type) VALUES ('3', '限定品', '3', 'tag');

-- Table: dtb_tax_rule
INSERT INTO dtb_tax_rule (id, apply_date, create_date, update_date, product_class_id, creator_id, country_id, pref_id, product_id, rounding_type_id, discriminator_type, tax_rate, tax_adjust) VALUES ('1', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '2017-03-07 10:14:52', NULL, NULL, NULL, NULL, NULL, '1', 'taxrule', '10', '0');

-- Table: dtb_template
INSERT INTO dtb_template (id, template_code, template_name, create_date, update_date, device_type_id, discriminator_type) VALUES ('1', 'default', 'デフォルト', '2017-03-07 10:14:52', '2017-03-07 10:14:52', '10', 'template');

-- Table: mtb_authority
INSERT INTO mtb_authority (id, name, sort_no, discriminator_type) VALUES ('0', 'システム管理者', '0', 'authority');
INSERT INTO mtb_authority (id, name, sort_no, discriminator_type) VALUES ('1', '店舗オーナー', '1', 'authority');

-- Table: mtb_country
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('352', 'アイスランド', '1', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('372', 'アイルランド', '2', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('31', 'アゼルバイジャン', '3', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('4', 'アフガニスタン', '4', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('840', 'アメリカ合衆国', '5', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('850', 'アメリカ領ヴァージン諸島', '6', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('16', 'アメリカ領サモア', '7', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('784', 'アラブ首長国連邦', '8', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('12', 'アルジェリア', '9', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('32', 'アルゼンチン', '10', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('533', 'アルバ', '11', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('8', 'アルバニア', '12', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('51', 'アルメニア', '13', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('660', 'アンギラ', '14', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('24', 'アンゴラ', '15', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('28', 'アンティグア・バーブーダ', '16', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('20', 'アンドラ', '17', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('887', 'イエメン', '18', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('826', 'イギリス', '19', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('86', 'イギリス領インド洋地域', '20', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('92', 'イギリス領ヴァージン諸島', '21', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('376', 'イスラエル', '22', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('380', 'イタリア', '23', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('368', 'イラク', '24', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('364', 'イラン|イラン・イスラム共和国', '25', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('356', 'インド', '26', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('360', 'インドネシア', '27', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('876', 'ウォリス・フツナ', '28', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('800', 'ウガンダ', '29', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('804', 'ウクライナ', '30', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('860', 'ウズベキスタン', '31', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('858', 'ウルグアイ', '32', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('218', 'エクアドル', '33', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('818', 'エジプト', '34', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('233', 'エストニア', '35', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('231', 'エチオピア', '36', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('232', 'エリトリア', '37', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('222', 'エルサルバドル', '38', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('36', 'オーストラリア', '39', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('40', 'オーストリア', '40', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('248', 'オーランド諸島', '41', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('512', 'オマーン', '42', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('528', 'オランダ', '43', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('288', 'ガーナ', '44', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('132', 'カーボベルデ', '45', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('831', 'ガーンジー', '46', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('328', 'ガイアナ', '47', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('398', 'カザフスタン', '48', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('634', 'カタール', '49', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('581', '合衆国領有小離島', '50', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('124', 'カナダ', '51', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('266', 'ガボン', '52', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('120', 'カメルーン', '53', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('270', 'ガンビア', '54', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('116', 'カンボジア', '55', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('580', '北マリアナ諸島', '56', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('324', 'ギニア', '57', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('624', 'ギニアビサウ', '58', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('196', 'キプロス', '59', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('192', 'キューバ', '60', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('531', 'キュラソー島|キュラソー', '61', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('300', 'ギリシャ', '62', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('296', 'キリバス', '63', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('417', 'キルギス', '64', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('320', 'グアテマラ', '65', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('312', 'グアドループ', '66', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('316', 'グアム', '67', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('414', 'クウェート', '68', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('184', 'クック諸島', '69', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('304', 'グリーンランド', '70', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('162', 'クリスマス島 (オーストラリア)|クリスマス島', '71', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('268', 'グルジア', '72', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('308', 'グレナダ', '73', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('191', 'クロアチア', '74', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('136', 'ケイマン諸島', '75', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('404', 'ケニア', '76', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('384', 'コートジボワール', '77', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('166', 'ココス諸島|ココス（キーリング）諸島', '78', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('188', 'コスタリカ', '79', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('174', 'コモロ', '80', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('170', 'コロンビア', '81', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('178', 'コンゴ共和国', '82', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('180', 'コンゴ民主共和国', '83', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('682', 'サウジアラビア', '84', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('239', 'サウスジョージア・サウスサンドウィッチ諸島', '85', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('882', 'サモア', '86', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('678', 'サントメ・プリンシペ', '87', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('652', 'サン・バルテルミー島|サン・バルテルミー', '88', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('894', 'ザンビア', '89', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('666', 'サンピエール島・ミクロン島', '90', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('674', 'サンマリノ', '91', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('663', 'サン・マルタン (西インド諸島)|サン・マルタン（フランス領）', '92', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('694', 'シエラレオネ', '93', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('262', 'ジブチ', '94', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('292', 'ジブラルタル', '95', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('832', 'ジャージー', '96', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('388', 'ジャマイカ', '97', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('760', 'シリア|シリア・アラブ共和国', '98', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('702', 'シンガポール', '99', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('534', 'シント・マールテン|シント・マールテン（オランダ領）', '100', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('716', 'ジンバブエ', '101', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('756', 'スイス', '102', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('752', 'スウェーデン', '103', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('729', 'スーダン', '104', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('744', 'スヴァールバル諸島およびヤンマイエン島', '105', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('724', 'スペイン', '106', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('740', 'スリナム', '107', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('144', 'スリランカ', '108', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('703', 'スロバキア', '109', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('705', 'スロベニア', '110', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('748', 'スワジランド', '111', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('690', 'セーシェル', '112', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('226', '赤道ギニア', '113', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('686', 'セネガル', '114', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('688', 'セルビア', '115', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('659', 'セントクリストファー・ネイビス', '116', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('670', 'セントビンセント・グレナディーン|セントビンセントおよびグレナディーン諸島', '117', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('426', 'レソト', '246', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('654', 'セントヘレナ・アセンションおよびトリスタンダクーニャ', '118', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('662', 'セントルシア', '119', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('706', 'ソマリア', '120', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('90', 'ソロモン諸島', '121', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('796', 'タークス・カイコス諸島', '122', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('764', 'タイ王国|タイ', '123', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('410', '大韓民国', '124', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('158', '台湾', '125', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('762', 'タジキスタン', '126', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('834', 'タンザニア', '127', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('203', 'チェコ', '128', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('148', 'チャド', '129', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('140', '中央アフリカ共和国', '130', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('156', '中華人民共和国|中国', '131', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('788', 'チュニジア', '132', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('408', '朝鮮民主主義人民共和国', '133', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('152', 'チリ', '134', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('798', 'ツバル', '135', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('208', 'デンマーク', '136', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('276', 'ドイツ', '137', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('768', 'トーゴ', '138', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('772', 'トケラウ', '139', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('214', 'ドミニカ共和国', '140', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('212', 'ドミニカ国', '141', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('780', 'トリニダード・トバゴ', '142', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('795', 'トルクメニスタン', '143', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('792', 'トルコ', '144', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('776', 'トンガ', '145', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('566', 'ナイジェリア', '146', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('520', 'ナウル', '147', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('516', 'ナミビア', '148', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('10', '南極', '149', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('570', 'ニウエ', '150', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('558', 'ニカラグア', '151', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('562', 'ニジェール', '152', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('392', '日本', '153', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('732', '西サハラ', '154', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('540', 'ニューカレドニア', '155', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('554', 'ニュージーランド', '156', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('524', 'ネパール', '157', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('574', 'ノーフォーク島', '158', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('578', 'ノルウェー', '159', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('334', 'ハード島とマクドナルド諸島', '160', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('48', 'バーレーン', '161', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('332', 'ハイチ', '162', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('586', 'パキスタン', '163', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('336', 'バチカン|バチカン市国', '164', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('591', 'パナマ', '165', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('548', 'バヌアツ', '166', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('44', 'バハマ', '167', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('598', 'パプアニューギニア', '168', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('60', 'バミューダ諸島|バミューダ', '169', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('585', 'パラオ', '170', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('600', 'パラグアイ', '171', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('52', 'バルバドス', '172', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('275', 'パレスチナ', '173', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('348', 'ハンガリー', '174', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('50', 'バングラデシュ', '175', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('626', '東ティモール', '176', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('612', 'ピトケアン諸島|ピトケアン', '177', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('242', 'フィジー', '178', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('608', 'フィリピン', '179', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('246', 'フィンランド', '180', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('64', 'ブータン', '181', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('74', 'ブーベ島', '182', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('630', 'プエルトリコ', '183', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('234', 'フェロー諸島', '184', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('238', 'フォークランド諸島|フォークランド（マルビナス）諸島', '185', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('76', 'ブラジル', '186', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('250', 'フランス', '187', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('254', 'フランス領ギアナ', '188', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('258', 'フランス領ポリネシア', '189', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('260', 'フランス領南方・南極地域', '190', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('100', 'ブルガリア', '191', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('854', 'ブルキナファソ', '192', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('96', 'ブルネイ|ブルネイ・ダルサラーム', '193', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('108', 'ブルンジ', '194', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('704', 'ベトナム', '195', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('204', 'ベナン', '196', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('862', 'ベネズエラ|ベネズエラ・ボリバル共和国', '197', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('112', 'ベラルーシ', '198', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('84', 'ベリーズ', '199', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('604', 'ペルー', '200', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('56', 'ベルギー', '201', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('616', 'ポーランド', '202', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('70', 'ボスニア・ヘルツェゴビナ', '203', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('72', 'ボツワナ', '204', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('535', 'BES諸島|ボネール、シント・ユースタティウスおよびサバ', '205', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('68', 'ボリビア|ボリビア多民族国', '206', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('620', 'ポルトガル', '207', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('344', '香港', '208', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('340', 'ホンジュラス', '209', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('584', 'マーシャル諸島', '210', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('446', 'マカオ', '211', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('807', 'マケドニア共和国|マケドニア旧ユーゴスラビア共和国', '212', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('450', 'マダガスカル', '213', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('175', 'マヨット', '214', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('454', 'マラウイ', '215', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('466', 'マリ共和国|マリ', '216', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('470', 'マルタ', '217', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('474', 'マルティニーク', '218', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('458', 'マレーシア', '219', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('833', 'マン島', '220', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('583', 'ミクロネシア連邦', '221', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('710', '南アフリカ共和国|南アフリカ', '222', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('728', '南スーダン', '223', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('104', 'ミャンマー', '224', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('484', 'メキシコ', '225', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('480', 'モーリシャス', '226', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('478', 'モーリタニア', '227', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('508', 'モザンビーク', '228', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('492', 'モナコ', '229', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('462', 'モルディブ', '230', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('498', 'モルドバ|モルドバ共和国', '231', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('504', 'モロッコ', '232', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('496', 'モンゴル国|モンゴル', '233', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('499', 'モンテネグロ', '234', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('500', 'モントセラト', '235', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('400', 'ヨルダン', '236', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('418', 'ラオス|ラオス人民民主共和国', '237', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('428', 'ラトビア', '238', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('440', 'リトアニア', '239', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('434', 'リビア', '240', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('438', 'リヒテンシュタイン', '241', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('430', 'リベリア', '242', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('642', 'ルーマニア', '243', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('442', 'ルクセンブルク', '244', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('646', 'ルワンダ', '245', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('422', 'レバノン', '247', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('638', 'レユニオン', '248', 'country');
INSERT INTO mtb_country (id, name, sort_no, discriminator_type) VALUES ('643', 'ロシア|ロシア連邦', '249', 'country');

-- Table: mtb_csv_type
INSERT INTO mtb_csv_type (id, name, sort_no, discriminator_type) VALUES ('1', '商品CSV', '3', 'csvtype');
INSERT INTO mtb_csv_type (id, name, sort_no, discriminator_type) VALUES ('2', '会員CSV', '4', 'csvtype');
INSERT INTO mtb_csv_type (id, name, sort_no, discriminator_type) VALUES ('3', '受注CSV', '1', 'csvtype');
INSERT INTO mtb_csv_type (id, name, sort_no, discriminator_type) VALUES ('4', '配送CSV', '1', 'csvtype');
INSERT INTO mtb_csv_type (id, name, sort_no, discriminator_type) VALUES ('5', 'カテゴリCSV', '5', 'csvtype');

-- Table: mtb_customer_order_status
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES ('1', '注文受付', '0', 'customerorderstatus');
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES ('3', '注文取消し', '4', 'customerorderstatus');
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES ('4', '注文受付', '3', 'customerorderstatus');
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES ('5', '発送済み', '6', 'customerorderstatus');
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES ('6', '注文受付', '2', 'customerorderstatus');
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES ('7', '注文受付', '1', 'customerorderstatus');
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES ('8', '注文未完了', '5', 'customerorderstatus');
INSERT INTO mtb_customer_order_status (id, name, sort_no, discriminator_type) VALUES ('9', '返品', '7', 'customerorderstatus');

-- Table: mtb_customer_status
INSERT INTO mtb_customer_status (id, name, sort_no, discriminator_type) VALUES ('1', '仮会員', '0', 'customerstatus');
INSERT INTO mtb_customer_status (id, name, sort_no, discriminator_type) VALUES ('2', '本会員', '1', 'customerstatus');
INSERT INTO mtb_customer_status (id, name, sort_no, discriminator_type) VALUES ('3', '退会', '2', 'customerstatus');

-- Table: mtb_device_type
INSERT INTO mtb_device_type (id, name, sort_no, discriminator_type) VALUES ('2', 'モバイル', '0', 'devicetype');
INSERT INTO mtb_device_type (id, name, sort_no, discriminator_type) VALUES ('10', 'PC', '1', 'devicetype');

-- Table: mtb_job
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('1', '公務員', '0', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('2', 'コンサルタント', '1', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('3', 'コンピューター関連技術職', '2', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('4', 'コンピューター関連以外の技術職', '3', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('5', '金融関係', '4', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('6', '医師', '5', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('7', '弁護士', '6', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('8', '総務・人事・事務', '7', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('9', '営業・販売', '8', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('10', '研究・開発', '9', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('11', '広報・宣伝', '10', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('12', '企画・マーケティング', '11', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('13', 'デザイン関係', '12', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('14', '会社経営・役員', '13', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('15', '出版・マスコミ関係', '14', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('16', '学生・フリーター', '15', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('17', '主婦', '16', 'job');
INSERT INTO mtb_job (id, name, sort_no, discriminator_type) VALUES ('18', 'その他', '17', 'job');

-- Table: mtb_order_item_type
INSERT INTO mtb_order_item_type (id, name, sort_no, discriminator_type) VALUES ('1', '商品', '0', 'orderitemtype');
INSERT INTO mtb_order_item_type (id, name, sort_no, discriminator_type) VALUES ('2', '送料', '1', 'orderitemtype');
INSERT INTO mtb_order_item_type (id, name, sort_no, discriminator_type) VALUES ('3', '手数料', '2', 'orderitemtype');
INSERT INTO mtb_order_item_type (id, name, sort_no, discriminator_type) VALUES ('4', '割引', '3', 'orderitemtype');
INSERT INTO mtb_order_item_type (id, name, sort_no, discriminator_type) VALUES ('5', '税', '4', 'orderitemtype');
INSERT INTO mtb_order_item_type (id, name, sort_no, discriminator_type) VALUES ('6', 'ポイント', '5', 'orderitemtype');

-- Table: mtb_order_status
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES ('1', '1', '新規受付', '0', 'orderstatus');
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES ('3', '0', '注文取消し', '3', 'orderstatus');
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES ('4', '1', '対応中', '2', 'orderstatus');
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES ('5', '0', '発送済み', '4', 'orderstatus');
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES ('6', '1', '入金済み', '1', 'orderstatus');
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES ('7', '0', '決済処理中', '6', 'orderstatus');
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES ('8', '0', '購入処理中', '5', 'orderstatus');
INSERT INTO mtb_order_status (id, display_order_count, name, sort_no, discriminator_type) VALUES ('9', '0', '返品', '7', 'orderstatus');

-- Table: mtb_order_status_color
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES ('1', '#437ec4', '0', 'orderstatuscolor');
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES ('3', '#C04949', '3', 'orderstatuscolor');
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES ('4', '#EEB128', '2', 'orderstatuscolor');
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES ('5', '#25B877', '4', 'orderstatuscolor');
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES ('6', '#25B877', '1', 'orderstatuscolor');
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES ('7', '#A3A3A3', '6', 'orderstatuscolor');
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES ('8', '#A3A3A3', '5', 'orderstatuscolor');
INSERT INTO mtb_order_status_color (id, name, sort_no, discriminator_type) VALUES ('9', '#C04949', '7', 'orderstatuscolor');

-- Table: mtb_page_max
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES ('10', '10', '0', 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES ('20', '20', '1', 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES ('30', '30', '2', 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES ('40', '40', '3', 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES ('50', '50', '4', 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES ('60', '60', '5', 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES ('70', '70', '6', 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES ('80', '80', '7', 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES ('90', '90', '8', 'pagemax');
INSERT INTO mtb_page_max (id, name, sort_no, discriminator_type) VALUES ('100', '100', '9', 'pagemax');

-- Table: mtb_pref
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('1', '北海道', '1', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('2', '青森県', '2', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('3', '岩手県', '3', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('4', '宮城県', '4', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('5', '秋田県', '5', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('6', '山形県', '6', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('7', '福島県', '7', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('8', '茨城県', '8', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('9', '栃木県', '9', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('10', '群馬県', '10', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('11', '埼玉県', '11', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('12', '千葉県', '12', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('13', '東京都', '13', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('14', '神奈川県', '14', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('15', '新潟県', '15', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('16', '富山県', '16', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('17', '石川県', '17', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('18', '福井県', '18', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('19', '山梨県', '19', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('20', '長野県', '20', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('21', '岐阜県', '21', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('22', '静岡県', '22', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('23', '愛知県', '23', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('24', '三重県', '24', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('25', '滋賀県', '25', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('26', '京都府', '26', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('27', '大阪府', '27', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('28', '兵庫県', '28', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('29', '奈良県', '29', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('30', '和歌山県', '30', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('31', '鳥取県', '31', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('32', '島根県', '32', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('33', '岡山県', '33', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('34', '広島県', '34', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('35', '山口県', '35', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('36', '徳島県', '36', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('37', '香川県', '37', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('38', '愛媛県', '38', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('39', '高知県', '39', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('40', '福岡県', '40', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('41', '佐賀県', '41', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('42', '長崎県', '42', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('43', '熊本県', '43', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('44', '大分県', '44', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('45', '宮崎県', '45', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('46', '鹿児島県', '46', 'pref');
INSERT INTO mtb_pref (id, name, sort_no, discriminator_type) VALUES ('47', '沖縄県', '47', 'pref');

-- Table: mtb_product_list_max
INSERT INTO mtb_product_list_max (id, name, sort_no, discriminator_type) VALUES ('20', '20件', '0', 'productlistmax');
INSERT INTO mtb_product_list_max (id, name, sort_no, discriminator_type) VALUES ('40', '40件', '1', 'productlistmax');
INSERT INTO mtb_product_list_max (id, name, sort_no, discriminator_type) VALUES ('60', '60件', '2', 'productlistmax');

-- Table: mtb_product_list_order_by
INSERT INTO mtb_product_list_order_by (id, name, sort_no, discriminator_type) VALUES ('1', '価格が低い順', '0', 'productlistorderby');
INSERT INTO mtb_product_list_order_by (id, name, sort_no, discriminator_type) VALUES ('2', '新着順', '2', 'productlistorderby');
INSERT INTO mtb_product_list_order_by (id, name, sort_no, discriminator_type) VALUES ('3', '価格が高い順', '1', 'productlistorderby');

-- Table: mtb_product_status
INSERT INTO mtb_product_status (id, name, sort_no, discriminator_type) VALUES ('1', '公開', '0', 'productstatus');
INSERT INTO mtb_product_status (id, name, sort_no, discriminator_type) VALUES ('2', '非公開', '1', 'productstatus');
INSERT INTO mtb_product_status (id, name, sort_no, discriminator_type) VALUES ('3', '廃止', '2', 'productstatus');

-- Table: mtb_rounding_type
INSERT INTO mtb_rounding_type (id, name, sort_no, discriminator_type) VALUES ('1', '四捨五入', '0', 'roundingtype');
INSERT INTO mtb_rounding_type (id, name, sort_no, discriminator_type) VALUES ('2', '切り捨て', '1', 'roundingtype');
INSERT INTO mtb_rounding_type (id, name, sort_no, discriminator_type) VALUES ('3', '切り上げ', '2', 'roundingtype');

-- Table: mtb_sale_type
INSERT INTO mtb_sale_type (id, name, sort_no, discriminator_type) VALUES ('1', '販売種別A', '0', 'saletype');
INSERT INTO mtb_sale_type (id, name, sort_no, discriminator_type) VALUES ('2', '販売種別B', '1', 'saletype');

-- Table: mtb_sex
INSERT INTO mtb_sex (id, name, sort_no, discriminator_type) VALUES ('1', '男性', '0', 'sex');
INSERT INTO mtb_sex (id, name, sort_no, discriminator_type) VALUES ('2', '女性', '1', 'sex');

-- Table: mtb_tax_display_type
INSERT INTO mtb_tax_display_type (id, name, sort_no, discriminator_type) VALUES ('1', '税抜', '0', 'taxdisplaytype');
INSERT INTO mtb_tax_display_type (id, name, sort_no, discriminator_type) VALUES ('2', '税込', '1', 'taxdisplaytype');

-- Table: mtb_tax_type
INSERT INTO mtb_tax_type (id, name, sort_no, discriminator_type) VALUES ('1', '課税', '0', 'taxtype');
INSERT INTO mtb_tax_type (id, name, sort_no, discriminator_type) VALUES ('2', '不課税', '1', 'taxtype');
INSERT INTO mtb_tax_type (id, name, sort_no, discriminator_type) VALUES ('3', '非課税', '2', 'taxtype');

-- Table: mtb_work
INSERT INTO mtb_work (id, name, sort_no, discriminator_type) VALUES ('0', '非稼働', '0', 'work');
INSERT INTO mtb_work (id, name, sort_no, discriminator_type) VALUES ('1', '稼働', '1', 'work');

